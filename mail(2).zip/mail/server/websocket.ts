import { WebSocketServer, WebSocket } from "ws";
import { Server } from "http";

let wss: WebSocketServer | null = null;

export function initWebSocket(server: Server) {
  wss = new WebSocketServer({ 
    server,
    path: "/ws"
  });

  wss.on("connection", (ws) => {
    console.log("[WebSocket] Client connected");
    
    ws.on("close", () => {
      console.log("[WebSocket] Client disconnected");
    });

    ws.on("error", (error) => {
      console.error("[WebSocket] Error:", error);
    });

    ws.send(JSON.stringify({ type: "connected", message: "WebSocket connected" }));
  });

  console.log("[WebSocket] Server initialized on /ws");
  return wss;
}

export function broadcastEmailUpdate(data: {
  type: "new_received" | "new_sent" | "sync_complete" | "campaign_completed" | "campaign_progress" | "campaign_started" | "campaign_resumed" | "campaign_finished";
  count?: number;
  timestamp?: string;
  campaignId?: string;
  sentCount?: number;
  failedCount?: number;
}) {
  if (!wss) {
    console.log("[WebSocket] Server not initialized");
    return;
  }

  const message = JSON.stringify({
    ...data,
    event: "email_update"
  });

  let clientCount = 0;
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
      clientCount++;
    }
  });

  if (clientCount > 0) {
    console.log(`[WebSocket] Broadcasted ${data.type} to ${clientCount} clients`);
  }
}

export function getWebSocketServer() {
  return wss;
}
