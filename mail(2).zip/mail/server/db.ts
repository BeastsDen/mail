import postgres from 'postgres';
import { drizzle } from 'drizzle-orm/postgres-js';
import * as schema from "@shared/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const client = postgres(process.env.DATABASE_URL, {
  prepare: false,
  max: 10,
  idle_timeout: 30,
  max_lifetime: 60 * 30,
  connect_timeout: 30,
  // Increase statement timeout to prevent query cancellation
  types: {
    bigint: postgres.BigInt,
  },
  onnotice: () => {}, // Suppress notices
  connection: {
    statement_timeout: 60000, // 60 seconds
    lock_timeout: 30000, // 30 seconds
  },
});

export const db = drizzle(client, { schema });
