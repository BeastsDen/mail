import { storage } from "./storage";
import { sendEmail, type EmailAttachment } from "./outlookClient";
import type { Campaign, DatasetContact, EmailTemplate } from "@shared/schema";
import { broadcastEmailUpdate } from "./websocket";

const BATCH_SIZE = 10;
const DEFAULT_DELAY_SECONDS = 2;
const PROCESSOR_INTERVAL_MS = 30000;
const CAMPAIGN_EMAIL_INSERT_BATCH_SIZE = 500;

let isProcessing = false;
let processorInterval: ReturnType<typeof setInterval> | null = null;

function log(message: string) {
  const time = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  console.log(`${time} [CampaignProcessor] ${message}`);
}

function getDayName(date: Date): string {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  return days[date.getDay()];
}

function isWithinSchedule(campaign: Campaign): boolean {
  if (!campaign.scheduledDays || campaign.scheduledDays.length === 0) {
    return true;
  }

  const now = new Date();
  const currentDay = getDayName(now);
  
  if (!campaign.scheduledDays.includes(currentDay)) {
    return false;
  }

  if (campaign.scheduleStartTime && campaign.scheduleEndTime) {
    const currentTime = now.toTimeString().slice(0, 5);
    
    if (currentTime < campaign.scheduleStartTime || currentTime > campaign.scheduleEndTime) {
      return false;
    }
  }

  return true;
}

async function autoStartScheduledCampaigns(): Promise<void> {
  try {
    const pendingCampaigns = await storage.getPendingCampaigns();
    
    for (const campaign of pendingCampaigns) {
      if (isWithinSchedule(campaign)) {
        log(`Auto-starting scheduled campaign: ${campaign.name}`);
        await storage.updateCampaignStatus(campaign.id, 'running');
        broadcastEmailUpdate({ type: 'campaign_started', campaignId: campaign.id });
      }
    }
    
    const pausedCampaigns = await storage.getActiveCampaigns();
    for (const campaign of pausedCampaigns) {
      if (campaign.status === 'paused' && isWithinSchedule(campaign)) {
        log(`Auto-resuming scheduled campaign: ${campaign.name}`);
        await storage.updateCampaignStatus(campaign.id, 'running');
        broadcastEmailUpdate({ type: 'campaign_resumed', campaignId: campaign.id });
      }
    }
  } catch (error: any) {
    log(`Error in autoStartScheduledCampaigns: ${error.message}`);
  }
}

function extractBase64Images(html: string): { processedHtml: string; attachments: EmailAttachment[] } {
  const attachments: EmailAttachment[] = [];
  let imageCounter = 0;
  
  const base64Regex = /src=["']data:(image\/[^;]+);base64,([^"']+)["']/gi;
  
  const processedHtml = html.replace(base64Regex, (match, mimeType, base64Data) => {
    imageCounter++;
    const contentId = `inline_image_${Date.now()}_${imageCounter}`;
    const extension = mimeType.split('/')[1] || 'png';
    
    attachments.push({
      name: `image_${imageCounter}.${extension}`,
      contentType: mimeType,
      contentBytes: base64Data,
      isInline: true,
      contentId: contentId,
    });
    
    return `src="cid:${contentId}"`;
  });
  
  return { processedHtml, attachments };
}

async function processContact(
  campaign: Campaign,
  campaignEmailId: string,
  contact: DatasetContact,
  template: EmailTemplate
): Promise<{ success: boolean; error?: string }> {
  try {
    const { processedHtml: processedTemplateBody, attachments: templateAttachments } = extractBase64Images(template.body);

    const replacements: Record<string, string> = {
      name: contact.name || "",
      email: contact.email,
      company: contact.company || "",
      number: contact.number || "",
      firstName: contact.name?.split(" ")[0] || "",
      lastName: contact.name?.split(" ").slice(1).join(" ") || "",
      ...(typeof contact.customFields === "object" ? contact.customFields as Record<string, string> : {}),
    };

    let subject = template.subject;
    let body = processedTemplateBody;

    Object.entries(replacements).forEach(([key, value]) => {
      const regex = new RegExp(`\\{\\{${key}\\}\\}`, "gi");
      subject = subject.replace(regex, String(value));
      body = body.replace(regex, String(value));
    });

    await sendEmail({
      to: [contact.email],
      subject,
      body,
      attachments: templateAttachments.length > 0 ? templateAttachments : undefined,
    });

    const sentEmail = await storage.createSentEmail({
      sentBy: campaign.createdBy,
      recipientEmail: contact.email,
      recipientName: contact.name || undefined,
      subject,
      body,
      templateId: campaign.templateId,
      datasetId: campaign.datasetId,
      contactId: contact.id,
      status: "sent",
      leadStatus: "unassigned",
    });

    await storage.updateCampaignEmailStatus(campaignEmailId, 'sent', sentEmail.id);

    return { success: true };
  } catch (error: any) {
    log(`Error sending to ${contact.email}: ${error.message}`);
    await storage.updateCampaignEmailStatus(campaignEmailId, 'failed', undefined, error.message);
    return { success: false, error: error.message };
  }
}

async function processCampaign(campaign: Campaign): Promise<void> {
  if (campaign.status !== 'running') {
    return;
  }

  if (!isWithinSchedule(campaign)) {
    log(`Campaign ${campaign.name} is outside scheduled time window, skipping`);
    return;
  }

  const template = await storage.getEmailTemplate(campaign.templateId);
  if (!template) {
    log(`Template not found for campaign ${campaign.name}, stopping campaign`);
    await storage.updateCampaignError(campaign.id, "Template not found");
    return;
  }

  const pendingEmails = await storage.getPendingCampaignEmails(campaign.id, BATCH_SIZE);
  
  if (pendingEmails.length === 0) {
    log(`Campaign ${campaign.name} finished - no more pending emails`);
    await storage.updateCampaignStatus(campaign.id, 'finished');
    broadcastEmailUpdate({ type: 'campaign_finished', campaignId: campaign.id });
    return;
  }

  log(`Processing ${pendingEmails.length} emails for campaign ${campaign.name}`);

  let sentCount = campaign.sentCount;
  let failedCount = campaign.failedCount;

  for (const campaignEmail of pendingEmails) {
    const currentCampaign = await storage.getCampaign(campaign.id);
    if (!currentCampaign || currentCampaign.status !== 'running') {
      log(`Campaign ${campaign.name} was paused/stopped, aborting batch`);
      return;
    }

    if (!isWithinSchedule(currentCampaign)) {
      log(`Campaign ${campaign.name} is now outside scheduled time window, pausing batch`);
      return;
    }

    const contact = await storage.getDatasetContact(campaignEmail.contactId);
    
    if (!contact) {
      await storage.updateCampaignEmailStatus(campaignEmail.id, 'failed', undefined, "Contact not found");
      failedCount++;
      continue;
    }

    const result = await processContact(campaign, campaignEmail.id, contact, template);
    
    if (result.success) {
      sentCount++;
    } else {
      failedCount++;
    }

    await storage.updateCampaignProgress(campaign.id, sentCount, failedCount, contact.id);

    // Use campaign's custom delay or default
    const delayMs = (campaign.delaySeconds || DEFAULT_DELAY_SECONDS) * 1000;
    await new Promise(resolve => setTimeout(resolve, delayMs));
  }

  broadcastEmailUpdate({ type: 'campaign_progress', campaignId: campaign.id, sentCount, failedCount });
}

async function runProcessor(): Promise<void> {
  if (isProcessing) {
    return;
  }

  isProcessing = true;

  try {
    await autoStartScheduledCampaigns();
    
    const activeCampaigns = await storage.getActiveCampaigns();
    
    for (const campaign of activeCampaigns) {
      if (campaign.status === 'running') {
        await processCampaign(campaign);
      }
    }
  } catch (error: any) {
    log(`Processor error: ${error.message}`);
  } finally {
    isProcessing = false;
  }
}

export function startCampaignProcessor(): void {
  if (processorInterval) {
    log("Campaign processor already running");
    return;
  }

  log("Starting campaign processor");
  
  runProcessor();
  
  processorInterval = setInterval(runProcessor, PROCESSOR_INTERVAL_MS);
}

export function stopCampaignProcessor(): void {
  if (processorInterval) {
    clearInterval(processorInterval);
    processorInterval = null;
    log("Campaign processor stopped");
  }
}

export async function initializeCampaign(campaignId: string, reinitialize: boolean = false): Promise<void> {
  const campaign = await storage.getCampaign(campaignId);
  if (!campaign) {
    throw new Error("Campaign not found");
  }

  if (reinitialize) {
    log(`Clearing existing campaign emails for restart: ${campaign.name}`);
    await storage.clearCampaignEmails(campaignId);
    await storage.updateCampaignProgress(campaignId, 0, 0);
  }

  const contacts = await storage.getDatasetContacts(campaign.datasetId);
  
  if (contacts.length === 0) {
    throw new Error("No contacts in dataset");
  }

  const campaignEmailData = contacts.map(contact => ({
    campaignId: campaign.id,
    contactId: contact.id,
    status: 'pending' as const,
  }));

  const insertedCount = await storage.createCampaignEmailsBatched(campaignEmailData, CAMPAIGN_EMAIL_INSERT_BATCH_SIZE);
  
  log(`Initialized campaign ${campaign.name} with ${insertedCount} emails (batched)`);
}

export async function retryFailedEmails(campaignId: string): Promise<number> {
  const campaign = await storage.getCampaign(campaignId);
  if (!campaign) {
    throw new Error("Campaign not found");
  }

  const resetCount = await storage.resetCampaignEmailsToRetry(campaignId);
  log(`Reset ${resetCount} failed emails for retry in campaign ${campaign.name}`);
  return resetCount;
}
