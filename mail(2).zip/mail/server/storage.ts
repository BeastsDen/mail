// Database storage implementation using Drizzle ORM
import {
  users,
  datasets,
  datasetContacts,
  emailTemplates,
  sentEmails,
  receivedEmails,
  emailThreads,
  activityLogs,
  campaigns,
  campaignEmails,
  type User,
  type UpsertUser,
  type Dataset,
  type InsertDataset,
  type DatasetContact,
  type InsertDatasetContact,
  type EmailTemplate,
  type InsertEmailTemplate,
  type SentEmail,
  type InsertSentEmail,
  type ReceivedEmail,
  type InsertReceivedEmail,
  type EmailThread,
  type InsertEmailThread,
  type ActivityLog,
  type InsertActivityLog,
  type Campaign,
  type InsertCampaign,
  type CampaignEmail,
  type InsertCampaignEmail,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, gt, desc, sql, or, inArray, isNull } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: UpsertUser): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUserRole(userId: string, role: string): Promise<User>;
  deleteUser(userId: string): Promise<void>;
  blockUser(userId: string, blockedUntil?: Date): Promise<User>;
  unblockUser(userId: string): Promise<User>;
  updatePassword(userId: string, passwordHash: string): Promise<User>;

  // Dataset operations
  createDataset(dataset: InsertDataset): Promise<Dataset>;
  getDataset(id: string): Promise<Dataset | undefined>;
  getDatasetsByUser(userId: string, limit?: number, offset?: number): Promise<Dataset[]>;
  getAllDatasets(limit?: number, offset?: number): Promise<Dataset[]>;
  getDatasetCount(userId?: string): Promise<number>;
  deleteDataset(id: string): Promise<void>;
  updateDatasetRecordCount(id: string, count: number): Promise<void>;

  // Dataset contacts operations
  createDatasetContact(contact: InsertDatasetContact): Promise<DatasetContact>;
  createDatasetContacts(contacts: InsertDatasetContact[]): Promise<DatasetContact[]>;
  getDatasetContacts(datasetId: string): Promise<DatasetContact[]>;
  getDatasetContact(contactId: string): Promise<DatasetContact | undefined>;
  getDatasetContactCount(datasetId: string): Promise<number>;
  searchAllContacts(query: string): Promise<Array<DatasetContact & { datasetName: string }>>;

  // Email template operations
  createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate>;
  getEmailTemplate(id: string): Promise<EmailTemplate | undefined>;
  getAllEmailTemplates(limit?: number, offset?: number): Promise<EmailTemplate[]>;
  getEmailTemplatesByUser(userId: string, limit?: number, offset?: number): Promise<EmailTemplate[]>;
  getTemplateCount(): Promise<number>;
  deleteEmailTemplate(id: string): Promise<void>;
  updateTemplateLastUsed(id: string): Promise<void>;

  // Sent email operations
  createSentEmail(email: InsertSentEmail): Promise<SentEmail>;
  getSentEmail(id: string): Promise<SentEmail | undefined>;
  getSentEmailsByUser(userId: string, limit?: number, offset?: number, leadStatus?: string): Promise<SentEmail[]>;
  getAllSentEmails(limit?: number, offset?: number, leadStatus?: string): Promise<SentEmail[]>;
  getSentEmailCount(userId?: string, leadStatus?: string): Promise<number>;
  updateEmailLeadStatus(emailId: string, leadStatus: string): Promise<void>;
  updateEmailStatus(emailId: string, status: string): Promise<void>;

  // Received email operations
  createReceivedEmail(email: InsertReceivedEmail): Promise<ReceivedEmail>;
  getReceivedEmail(id: string): Promise<ReceivedEmail | undefined>;
  getReceivedEmailsByUser(userId: string, limit?: number, offset?: number): Promise<ReceivedEmail[]>;
  getAllReceivedEmails(limit?: number, offset?: number, leadStatus?: string): Promise<ReceivedEmail[]>;
  getReceivedEmailCount(leadStatus?: string): Promise<number>;
  updateReceivedEmailLeadStatus(id: string, leadStatus: string): Promise<ReceivedEmail | undefined>;
  syncReceivedEmail(email: Omit<InsertReceivedEmail, 'id'>): Promise<{ email: ReceivedEmail; isNew: boolean }>;
  syncSentEmail(email: Omit<InsertSentEmail, 'id'>): Promise<{ email: SentEmail; isNew: boolean }>;

  // Email thread operations
  getEmailThreads(leadStatus?: string, limit?: number, offset?: number): Promise<EmailThread[]>;
  getEmailThread(threadId: string): Promise<EmailThread | undefined>;
  getThreadMessages(threadId: string): Promise<Array<SentEmail | ReceivedEmail>>;
  updateThreadStatus(threadId: string, leadStatus: string): Promise<EmailThread>;
  createOrUpdateThread(thread: Omit<InsertEmailThread, 'id'>): Promise<EmailThread>;
  getEmailThreadsForUser(userId: string, leadStatus?: string, limit?: number, offset?: number): Promise<EmailThread[]>;
  getEmailThreadCount(userId: string, leadStatus?: string): Promise<number>;

  // Activity log operations
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getActivityLogs(limit?: number): Promise<ActivityLog[]>;
  getActivityLogsByUser(userId: string, limit?: number): Promise<ActivityLog[]>;

  // Analytics operations
  getEmailCountByDateRange(userId: string, startDate: Date, endDate: Date): Promise<number>;
  getEmailCountByDateRangeAllUsers(startDate: Date, endDate: Date): Promise<number>;
  getLeadCountsByStatus(userId: string): Promise<{ hot: number; cold: number; dead: number }>;
  getTotalReplies(userId: string): Promise<number>;
  getEmailTrends(userId: string, days: number): Promise<Array<{ date: string; count: number }>>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getAllUsers(limit: number = 10000): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt)).limit(limit);
  }

  async updateUserRole(userId: string, role: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(userData: UpsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async deleteUser(userId: string): Promise<void> {
    await db.delete(users).where(eq(users.id, userId));
  }

  async blockUser(userId: string, blockedUntil?: Date): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        isBlocked: true, 
        blockedUntil: blockedUntil || null,
        updatedAt: new Date() 
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async unblockUser(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        isBlocked: false, 
        blockedUntil: null,
        updatedAt: new Date() 
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updatePassword(userId: string, passwordHash: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        passwordHash, 
        passwordChangedAt: new Date(),
        updatedAt: new Date() 
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Dataset operations
  async createDataset(datasetData: InsertDataset): Promise<Dataset> {
    const [dataset] = await db.insert(datasets).values(datasetData).returning();
    return dataset;
  }

  async getDataset(id: string): Promise<Dataset | undefined> {
    const [dataset] = await db.select().from(datasets).where(eq(datasets.id, id));
    return dataset || undefined;
  }

  async getDatasetsByUser(userId: string, limit: number = 20, offset: number = 0): Promise<Dataset[]> {
    return await db
      .select()
      .from(datasets)
      .where(eq(datasets.uploadedBy, userId))
      .orderBy(desc(datasets.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getAllDatasets(limit: number = 20, offset: number = 0): Promise<Dataset[]> {
    return await db.select().from(datasets).orderBy(desc(datasets.createdAt)).limit(limit).offset(offset);
  }

  async getDatasetCount(userId?: string): Promise<number> {
    if (userId) {
      const result = await db.select({ count: sql<number>`count(*)` }).from(datasets).where(eq(datasets.uploadedBy, userId));
      return Number(result[0]?.count || 0);
    }
    const result = await db.select({ count: sql<number>`count(*)` }).from(datasets);
    return Number(result[0]?.count || 0);
  }

  async deleteDataset(id: string): Promise<void> {
    await db.delete(datasets).where(eq(datasets.id, id));
  }

  async updateDatasetRecordCount(id: string, count: number): Promise<void> {
    await db.update(datasets).set({ recordsCount: count }).where(eq(datasets.id, id));
  }

  // Dataset contacts operations
  async createDatasetContact(contactData: InsertDatasetContact): Promise<DatasetContact> {
    const [contact] = await db.insert(datasetContacts).values(contactData).returning();
    return contact;
  }

  async createDatasetContacts(contactsData: InsertDatasetContact[]): Promise<DatasetContact[]> {
    if (contactsData.length === 0) return [];
    return await db.insert(datasetContacts).values(contactsData).returning();
  }

  async getDatasetContacts(datasetId: string): Promise<DatasetContact[]> {
    return await db
      .select()
      .from(datasetContacts)
      .where(eq(datasetContacts.datasetId, datasetId));
  }

  async getDatasetContact(contactId: string): Promise<DatasetContact | undefined> {
    const [contact] = await db
      .select()
      .from(datasetContacts)
      .where(eq(datasetContacts.id, contactId))
      .limit(1);
    return contact;
  }

  async getDatasetContactCount(datasetId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(datasetContacts)
      .where(eq(datasetContacts.datasetId, datasetId));
    return result?.count || 0;
  }

  async searchAllContacts(query: string): Promise<Array<DatasetContact & { datasetName: string }>> {
    const searchPattern = `%${query.toLowerCase()}%`;
    const results = await db
      .select({
        id: datasetContacts.id,
        datasetId: datasetContacts.datasetId,
        name: datasetContacts.name,
        email: datasetContacts.email,
        company: datasetContacts.company,
        number: datasetContacts.number,
        customFields: datasetContacts.customFields,
        createdAt: datasetContacts.createdAt,
        datasetName: datasets.name,
      })
      .from(datasetContacts)
      .leftJoin(datasets, eq(datasetContacts.datasetId, datasets.id))
      .where(
        or(
          sql`LOWER(${datasetContacts.email}) LIKE ${searchPattern}`,
          sql`LOWER(${datasetContacts.name}) LIKE ${searchPattern}`,
          sql`LOWER(${datasetContacts.company}) LIKE ${searchPattern}`,
          sql`LOWER(${datasetContacts.number}) LIKE ${searchPattern}`
        )
      )
      .limit(100);
    
    return results.map(r => ({
      ...r,
      datasetName: r.datasetName || 'Unknown Dataset'
    }));
  }

  // Email template operations
  async createEmailTemplate(templateData: InsertEmailTemplate): Promise<EmailTemplate> {
    const [template] = await db.insert(emailTemplates).values(templateData).returning();
    return template;
  }

  async getEmailTemplate(id: string): Promise<EmailTemplate | undefined> {
    const [template] = await db.select().from(emailTemplates).where(eq(emailTemplates.id, id));
    return template || undefined;
  }

  async getAllEmailTemplates(limit: number = 20, offset: number = 0): Promise<EmailTemplate[]> {
    return await db.select().from(emailTemplates).orderBy(desc(emailTemplates.createdAt)).limit(limit).offset(offset);
  }

  async getEmailTemplatesByUser(userId: string, limit: number = 20, offset: number = 0): Promise<EmailTemplate[]> {
    return await db
      .select()
      .from(emailTemplates)
      .where(eq(emailTemplates.createdBy, userId))
      .orderBy(desc(emailTemplates.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getTemplateCount(): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)` }).from(emailTemplates);
    return Number(result[0]?.count || 0);
  }

  async deleteEmailTemplate(id: string): Promise<void> {
    await db.delete(emailTemplates).where(eq(emailTemplates.id, id));
  }

  async updateTemplateLastUsed(id: string): Promise<void> {
    await db
      .update(emailTemplates)
      .set({ lastUsed: new Date() })
      .where(eq(emailTemplates.id, id));
  }

  // Sent email operations
  async createSentEmail(emailData: InsertSentEmail): Promise<SentEmail> {
    const [email] = await db.insert(sentEmails).values(emailData).returning();
    return email;
  }

  async getSentEmail(id: string): Promise<SentEmail | undefined> {
    const [email] = await db.select().from(sentEmails).where(eq(sentEmails.id, id));
    return email || undefined;
  }

  async getSentEmailsByUser(userId: string, limit: number = 20, offset: number = 0, leadStatus?: string): Promise<SentEmail[]> {
    // Build conditions array
    const conditions = [eq(sentEmails.sentBy, userId)];
    
    if (leadStatus && leadStatus !== 'all') {
      if (leadStatus === 'unassigned') {
        conditions.push(or(
          isNull(sentEmails.leadStatus),
          eq(sentEmails.leadStatus, '')
        ) as any);
      } else {
        conditions.push(eq(sentEmails.leadStatus, leadStatus));
      }
    }

    return await db
      .select()
      .from(sentEmails)
      .where(and(...conditions))
      .orderBy(desc(sentEmails.sentAt))
      .limit(limit)
      .offset(offset);
  }

  async getAllSentEmails(limit: number = 20, offset: number = 0, leadStatus?: string): Promise<SentEmail[]> {
    // Handle different lead status filters
    let condition;
    if (leadStatus && leadStatus !== 'all') {
      if (leadStatus === 'unassigned') {
        condition = or(
          isNull(sentEmails.leadStatus),
          eq(sentEmails.leadStatus, '')
        );
      } else {
        condition = eq(sentEmails.leadStatus, leadStatus);
      }
    }

    if (condition) {
      return await db
        .select()
        .from(sentEmails)
        .where(condition)
        .orderBy(desc(sentEmails.sentAt))
        .limit(limit)
        .offset(offset);
    }

    return await db.select().from(sentEmails).orderBy(desc(sentEmails.sentAt)).limit(limit).offset(offset);
  }

  async getSentEmailCount(userId?: string, leadStatus?: string): Promise<number> {
    // Build conditions array
    const conditions: any[] = [];
    
    if (userId) {
      conditions.push(eq(sentEmails.sentBy, userId));
    }
    
    if (leadStatus && leadStatus !== 'all') {
      if (leadStatus === 'unassigned') {
        conditions.push(or(
          isNull(sentEmails.leadStatus),
          eq(sentEmails.leadStatus, '')
        ));
      } else {
        conditions.push(eq(sentEmails.leadStatus, leadStatus));
      }
    }

    if (conditions.length > 0) {
      const result = await db
        .select({ count: sql<number>`count(*)` })
        .from(sentEmails)
        .where(and(...conditions));
      return Number(result[0]?.count || 0);
    }
    
    const result = await db.select({ count: sql<number>`count(*)` }).from(sentEmails);
    return Number(result[0]?.count || 0);
  }

  async updateEmailLeadStatus(emailId: string, leadStatus: string): Promise<void> {
    await db
      .update(sentEmails)
      .set({ leadStatus, updatedAt: new Date() })
      .where(eq(sentEmails.id, emailId));
  }

  async updateEmailStatus(emailId: string, status: string): Promise<void> {
    await db
      .update(sentEmails)
      .set({ status, updatedAt: new Date() })
      .where(eq(sentEmails.id, emailId));
  }

  // Received email operations
  async createReceivedEmail(emailData: InsertReceivedEmail): Promise<ReceivedEmail> {
    const [email] = await db.insert(receivedEmails).values(emailData).returning();
    return email;
  }

  async getReceivedEmail(id: string): Promise<ReceivedEmail | undefined> {
    const email = await db
      .select()
      .from(receivedEmails)
      .where(eq(receivedEmails.id, id))
      .limit(1);
    return email[0];
  }

  async getReceivedEmailsByUser(userId: string, limit: number = 20, offset: number = 0): Promise<ReceivedEmail[]> {
    return await db
      .select()
      .from(receivedEmails)
      .where(eq(receivedEmails.receivedBy, userId))
      .orderBy(desc(receivedEmails.receivedAt))
      .limit(limit)
      .offset(offset);
  }

  async getAllReceivedEmails(limit: number = 20, offset: number = 0, leadStatus?: string): Promise<ReceivedEmail[]> {
    // Handle different lead status filters
    let condition;
    if (leadStatus && leadStatus !== 'all') {
      if (leadStatus === 'unassigned') {
        // Unassigned means leadStatus is null or empty or 'unassigned'
        condition = or(
          isNull(receivedEmails.leadStatus),
          eq(receivedEmails.leadStatus, ''),
          eq(receivedEmails.leadStatus, 'unassigned')
        );
      } else {
        condition = eq(receivedEmails.leadStatus, leadStatus);
      }
    }

    if (condition) {
      return await db
        .select()
        .from(receivedEmails)
        .where(condition)
        .orderBy(desc(receivedEmails.receivedAt))
        .limit(limit)
        .offset(offset);
    }

    return await db
      .select()
      .from(receivedEmails)
      .orderBy(desc(receivedEmails.receivedAt))
      .limit(limit)
      .offset(offset);
  }

  async getReceivedEmailCount(leadStatus?: string): Promise<number> {
    // Handle different lead status filters
    let condition;
    if (leadStatus && leadStatus !== 'all') {
      if (leadStatus === 'unassigned') {
        condition = or(
          isNull(receivedEmails.leadStatus),
          eq(receivedEmails.leadStatus, ''),
          eq(receivedEmails.leadStatus, 'unassigned')
        );
      } else {
        condition = eq(receivedEmails.leadStatus, leadStatus);
      }
    }

    if (condition) {
      const result = await db
        .select({ count: sql<number>`count(*)` })
        .from(receivedEmails)
        .where(condition);
      return Number(result[0]?.count || 0);
    }

    const result = await db.select({ count: sql<number>`count(*)` }).from(receivedEmails);
    return Number(result[0]?.count || 0);
  }
  
  async updateReceivedEmailLeadStatus(id: string, leadStatus: string): Promise<ReceivedEmail | undefined> {
    const [updated] = await db
      .update(receivedEmails)
      .set({ leadStatus })
      .where(eq(receivedEmails.id, id))
      .returning();
    return updated;
  }

  // Activity log operations
  async createActivityLog(logData: InsertActivityLog): Promise<ActivityLog> {
    const [log] = await db.insert(activityLogs).values(logData).returning();
    return log;
  }

  async getActivityLogs(limit: number = 50): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .orderBy(desc(activityLogs.createdAt))
      .limit(limit);
  }

  async getActivityLogsByUser(userId: string, limit: number = 50): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .where(eq(activityLogs.userId, userId))
      .orderBy(desc(activityLogs.createdAt))
      .limit(limit);
  }

  // Analytics operations
  async getEmailCountByDateRange(
    userId: string,
    startDate: Date,
    endDate: Date
  ): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(sentEmails)
      .where(
        and(
          eq(sentEmails.sentBy, userId),
          gte(sentEmails.sentAt, startDate),
          lte(sentEmails.sentAt, endDate)
        )
      );
    return result?.count || 0;
  }

  async getEmailCountByDateRangeAllUsers(
    startDate: Date,
    endDate: Date
  ): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(sentEmails)
      .where(
        and(
          gte(sentEmails.sentAt, startDate),
          lte(sentEmails.sentAt, endDate)
        )
      );
    return result?.count || 0;
  }

  async getLeadCountsByStatus(
    userId: string
  ): Promise<{ hot: number; cold: number; dead: number }> {
    const results = await db
      .select({
        leadStatus: sentEmails.leadStatus,
        count: sql<number>`count(*)::int`,
      })
      .from(sentEmails)
      .where(eq(sentEmails.sentBy, userId))
      .groupBy(sentEmails.leadStatus);

    const counts = { hot: 0, cold: 0, dead: 0 };
    results.forEach((r) => {
      if (r.leadStatus === "hot") counts.hot = r.count;
      if (r.leadStatus === "cold") counts.cold = r.count;
      if (r.leadStatus === "dead") counts.dead = r.count;
    });

    return counts;
  }

  async getTotalReplies(userId: string): Promise<number> {
    const [result] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(sentEmails)
      .where(and(eq(sentEmails.sentBy, userId), eq(sentEmails.replied, true)));
    return result?.count || 0;
  }

  async getEmailTrends(
    userId: string,
    days: number
  ): Promise<Array<{ date: string; count: number }>> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const results = await db
      .select({
        date: sql<string>`DATE(${sentEmails.sentAt})`,
        count: sql<number>`count(*)::int`,
      })
      .from(sentEmails)
      .where(and(eq(sentEmails.sentBy, userId), gte(sentEmails.sentAt, startDate)))
      .groupBy(sql`DATE(${sentEmails.sentAt})`)
      .orderBy(sql`DATE(${sentEmails.sentAt})`);

    return results;
  }

  // Email sync operations
  async syncReceivedEmail(email: Omit<InsertReceivedEmail, 'id'>): Promise<{ email: ReceivedEmail; isNew: boolean }> {
    // Check if message already exists first
    const [existing] = await db
      .select()
      .from(receivedEmails)
      .where(eq(receivedEmails.messageId, email.messageId || ''));

    if (existing) {
      // Message exists, just ensure thread exists and update threadId if needed
      const thread = await this.createOrUpdateThread({
        conversationId: email.conversationId || '',
        subject: email.subject,
        participantEmails: [email.senderEmail],
        leadStatus: 'unassigned',
        lastMessageAt: email.receivedAt,
        unreadCount: 0, // Don't increment for existing messages
      });

      const [updated] = await db
        .update(receivedEmails)
        .set({ ...email, threadId: thread.id })
        .where(eq(receivedEmails.id, existing.id))
        .returning();

      return { email: updated, isNew: false };
    }

    // New message - create thread and add the message
    const thread = await this.createOrUpdateThread({
      conversationId: email.conversationId || '',
      subject: email.subject,
      participantEmails: [email.senderEmail],
      leadStatus: 'unassigned',
      lastMessageAt: email.receivedAt,
      unreadCount: 0, // Will be updated after insert
    });

    const [created] = await db
      .insert(receivedEmails)
      .values({ ...email, threadId: thread.id })
      .returning();

    // Refresh counts after inserting new message
    await this.refreshThreadMessageCount(thread.id);
    await this.refreshThreadUnreadCount(thread.id);

    return { email: created, isNew: true };
  }

  async syncSentEmail(email: Omit<InsertSentEmail, 'id'>): Promise<{ email: SentEmail; isNew: boolean }> {
    // Check if message already exists by messageId
    const [existingByMessageId] = await db
      .select()
      .from(sentEmails)
      .where(eq(sentEmails.messageId, email.messageId || ''));

    if (existingByMessageId) {
      // Message exists, just ensure thread exists and update threadId if needed
      const thread = await this.createOrUpdateThread({
        conversationId: email.conversationId || '',
        subject: email.subject,
        participantEmails: [email.recipientEmail],
        leadStatus: email.leadStatus || 'unassigned',
        lastMessageAt: email.sentAt || new Date(),
        unreadCount: 0, // Don't increment for existing messages
      });

      const [updated] = await db
        .update(sentEmails)
        .set({ ...email, threadId: thread.id, updatedAt: new Date() })
        .where(eq(sentEmails.id, existingByMessageId.id))
        .returning();

      return { email: updated, isNew: false };
    }

    // Try to match locally-created email without messageId (sent via app, not yet synced)
    // Match by recipient email + similar subject + sent within 10 minutes
    const sentTime = email.sentAt ? new Date(email.sentAt) : new Date();
    const tenMinutesBefore = new Date(sentTime.getTime() - 10 * 60 * 1000);
    const tenMinutesAfter = new Date(sentTime.getTime() + 10 * 60 * 1000);
    
    // Normalize subject for comparison (remove Re:, Fwd:, extra spaces)
    const normalizeSubject = (subj: string) => 
      subj.replace(/^(re:|fwd:|fw:)\s*/gi, '').trim().toLowerCase();
    const normalizedSubject = normalizeSubject(email.subject);
    
    const [matchingLocal] = await db
      .select()
      .from(sentEmails)
      .where(and(
        eq(sentEmails.recipientEmail, email.recipientEmail),
        isNull(sentEmails.messageId),
        gte(sentEmails.createdAt, tenMinutesBefore),
        lte(sentEmails.createdAt, tenMinutesAfter)
      ))
      .orderBy(desc(sentEmails.createdAt))
      .limit(1);
    
    if (matchingLocal && normalizeSubject(matchingLocal.subject) === normalizedSubject) {
      // Found a locally-created email, update it with Outlook data
      const thread = await this.createOrUpdateThread({
        conversationId: email.conversationId || '',
        subject: email.subject,
        participantEmails: [email.recipientEmail],
        leadStatus: matchingLocal.leadStatus || email.leadStatus || 'unassigned',
        lastMessageAt: email.sentAt || new Date(),
        unreadCount: 0,
      });

      const [updated] = await db
        .update(sentEmails)
        .set({ 
          messageId: email.messageId,
          conversationId: email.conversationId,
          threadId: thread.id,
          sentAt: email.sentAt,
          updatedAt: new Date() 
        })
        .where(eq(sentEmails.id, matchingLocal.id))
        .returning();

      // Refresh counts 
      await this.refreshThreadMessageCount(thread.id);

      return { email: updated, isNew: false };
    }

    // New message - create thread and add the message
    const thread = await this.createOrUpdateThread({
      conversationId: email.conversationId || '',
      subject: email.subject,
      participantEmails: [email.recipientEmail],
      leadStatus: email.leadStatus || 'unassigned',
      lastMessageAt: email.sentAt || new Date(),
      unreadCount: 0, // Will be updated after insert
    });

    const [created] = await db
      .insert(sentEmails)
      .values({ ...email, threadId: thread.id })
      .returning();

    // Refresh counts after inserting new message
    await this.refreshThreadMessageCount(thread.id);
    await this.refreshThreadUnreadCount(thread.id);

    return { email: created, isNew: true };
  }

  // Email thread operations - only returns threads with multiple messages (actual conversations)
  async getEmailThreads(leadStatus?: string, limit: number = 20, offset: number = 0): Promise<EmailThread[]> {
    if (leadStatus && leadStatus !== 'all') {
      return await db
        .select()
        .from(emailThreads)
        .where(and(
          eq(emailThreads.leadStatus, leadStatus),
          gt(emailThreads.messageCount, 1)
        ))
        .orderBy(desc(emailThreads.lastMessageAt))
        .limit(limit)
        .offset(offset);
    }
    
    return await db
      .select()
      .from(emailThreads)
      .where(gt(emailThreads.messageCount, 1))
      .orderBy(desc(emailThreads.lastMessageAt))
      .limit(limit)
      .offset(offset);
  }

  async getEmailThreadsForUser(userId: string, leadStatus?: string, limit: number = 20, offset: number = 0): Promise<EmailThread[]> {
    // Get all threads with multiple messages (not filtering by user - shared mailbox)
    if (leadStatus && leadStatus !== 'all') {
      return await db
        .select()
        .from(emailThreads)
        .where(and(
          eq(emailThreads.leadStatus, leadStatus),
          gt(emailThreads.messageCount, 1)
        ))
        .orderBy(desc(emailThreads.lastMessageAt))
        .limit(limit)
        .offset(offset);
    }

    return await db
      .select()
      .from(emailThreads)
      .where(gt(emailThreads.messageCount, 1))
      .orderBy(desc(emailThreads.lastMessageAt))
      .limit(limit)
      .offset(offset);
  }

  async getEmailThreadCount(userId: string, leadStatus?: string): Promise<number> {
    if (leadStatus && leadStatus !== 'all') {
      const result = await db.select({ count: sql<number>`count(*)` }).from(emailThreads).where(and(
        eq(emailThreads.leadStatus, leadStatus),
        gt(emailThreads.messageCount, 1)
      ));
      return Number(result[0]?.count || 0);
    }
    const result = await db.select({ count: sql<number>`count(*)` }).from(emailThreads).where(gt(emailThreads.messageCount, 1));
    return Number(result[0]?.count || 0);
  }

  async getEmailThread(threadId: string): Promise<EmailThread | undefined> {
    const [thread] = await db
      .select()
      .from(emailThreads)
      .where(eq(emailThreads.id, threadId));
    return thread || undefined;
  }

  async getThreadMessages(threadId: string): Promise<Array<SentEmail | ReceivedEmail>> {
    // Get the thread first to get conversationId as fallback
    const thread = await this.getEmailThread(threadId);
    
    // Try by threadId first, fallback to conversationId
    const [sent, received] = await Promise.all([
      db.select().from(sentEmails).where(
        thread?.conversationId 
          ? or(
              eq(sentEmails.threadId, threadId),
              eq(sentEmails.conversationId, thread.conversationId)
            )!
          : eq(sentEmails.threadId, threadId)
      ),
      db.select().from(receivedEmails).where(
        thread?.conversationId
          ? or(
              eq(receivedEmails.threadId, threadId),
              eq(receivedEmails.conversationId, thread.conversationId)
            )!
          : eq(receivedEmails.threadId, threadId)
      )
    ]);

    const allMessages = [
      ...sent.map(m => ({ ...m, type: 'sent' as const })),
      ...received.map(m => ({ ...m, type: 'received' as const }))
    ].sort((a, b) => {
      const dateA = 'sentAt' in a ? a.sentAt : a.receivedAt;
      const dateB = 'sentAt' in b ? b.sentAt : b.receivedAt;
      return new Date(dateA || 0).getTime() - new Date(dateB || 0).getTime();
    });

    return allMessages;
  }

  async updateThreadStatus(threadId: string, leadStatus: string): Promise<EmailThread> {
    const [updated] = await db
      .update(emailThreads)
      .set({ leadStatus, updatedAt: new Date() })
      .where(eq(emailThreads.id, threadId))
      .returning();
    return updated;
  }

  async createOrUpdateThread(thread: Omit<InsertEmailThread, 'id' | 'messageCount'>): Promise<EmailThread> {
    const [existing] = await db
      .select()
      .from(emailThreads)
      .where(eq(emailThreads.conversationId, thread.conversationId));

    if (existing) {
      // Only update lastMessageAt if the new message is newer
      const shouldUpdateTime = new Date(thread.lastMessageAt).getTime() > new Date(existing.lastMessageAt).getTime();
      
      // Deduplicate participant emails
      const currentParticipants = existing.participantEmails || [];
      const newParticipants = thread.participantEmails || [];
      const allParticipants = Array.from(new Set([...currentParticipants, ...newParticipants]));

      const [updated] = await db
        .update(emailThreads)
        .set({
          subject: thread.subject,
          lastMessageAt: shouldUpdateTime ? thread.lastMessageAt : existing.lastMessageAt,
          unreadCount: (thread.unreadCount || 0) > 0 
            ? existing.unreadCount + (thread.unreadCount || 0)
            : existing.unreadCount,
          participantEmails: allParticipants,
          updatedAt: new Date(),
        })
        .where(eq(emailThreads.id, existing.id))
        .returning();

      // Don't need to refresh counts here - only when new messages are added

      return updated;
    }

    // For new threads, start with messageCount of 0, it will be updated after email is inserted
    const [created] = await db
      .insert(emailThreads)
      .values({ ...thread, messageCount: 0 })
      .returning();

    return created;
  }

  private async refreshThreadMessageCount(threadId: string): Promise<void> {
    const [sentCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(sentEmails)
      .where(eq(sentEmails.threadId, threadId));

    const [receivedCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(receivedEmails)
      .where(eq(receivedEmails.threadId, threadId));

    const totalCount = (sentCount?.count || 0) + (receivedCount?.count || 0);

    await db
      .update(emailThreads)
      .set({ messageCount: totalCount })
      .where(eq(emailThreads.id, threadId));
  }

  private async refreshThreadUnreadCount(threadId: string): Promise<void> {
    const [unreadCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(receivedEmails)
      .where(and(
        eq(receivedEmails.threadId, threadId),
        eq(receivedEmails.isRead, false)
      ));

    await db
      .update(emailThreads)
      .set({ unreadCount: unreadCount?.count || 0 })
      .where(eq(emailThreads.id, threadId));
  }

  // Campaign operations
  async createCampaign(campaignData: InsertCampaign): Promise<Campaign> {
    const [campaign] = await db.insert(campaigns).values(campaignData).returning();
    return campaign;
  }

  async getCampaign(id: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign || undefined;
  }

  async getCampaignsByUser(userId: string, limit: number = 20, offset: number = 0): Promise<Campaign[]> {
    return await db
      .select()
      .from(campaigns)
      .where(eq(campaigns.createdBy, userId))
      .orderBy(desc(campaigns.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getAllCampaigns(limit: number = 20, offset: number = 0): Promise<Campaign[]> {
    return await db
      .select()
      .from(campaigns)
      .orderBy(desc(campaigns.createdAt))
      .limit(limit)
      .offset(offset);
  }

  async getCampaignCount(userId?: string): Promise<number> {
    if (userId) {
      const result = await db.select({ count: sql<number>`count(*)` }).from(campaigns).where(eq(campaigns.createdBy, userId));
      return Number(result[0]?.count || 0);
    }
    const result = await db.select({ count: sql<number>`count(*)` }).from(campaigns);
    return Number(result[0]?.count || 0);
  }

  async updateCampaignStatus(id: string, status: string): Promise<Campaign> {
    const updates: any = { status, updatedAt: new Date() };
    
    if (status === 'running' && !(await this.getCampaign(id))?.startedAt) {
      updates.startedAt = new Date();
    }
    if (status === 'completed' || status === 'stopped' || status === 'finished') {
      updates.completedAt = new Date();
    }
    
    const [updated] = await db
      .update(campaigns)
      .set(updates)
      .where(eq(campaigns.id, id))
      .returning();
    return updated;
  }

  async updateCampaignProgress(id: string, sentCount: number, failedCount: number, lastContactId?: string): Promise<void> {
    await db
      .update(campaigns)
      .set({
        sentCount,
        failedCount,
        lastProcessedContactId: lastContactId,
        lastProcessedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(campaigns.id, id));
  }

  async updateCampaignError(id: string, errorMessage: string): Promise<void> {
    await db
      .update(campaigns)
      .set({
        errorMessage,
        status: 'stopped',
        updatedAt: new Date(),
      })
      .where(eq(campaigns.id, id));
  }

  async deleteCampaign(id: string): Promise<void> {
    await db.delete(campaigns).where(eq(campaigns.id, id));
  }

  async getActiveCampaigns(): Promise<Campaign[]> {
    return await db
      .select()
      .from(campaigns)
      .where(or(
        eq(campaigns.status, 'running'),
        eq(campaigns.status, 'paused')
      ))
      .orderBy(campaigns.createdAt);
  }

  async getPendingCampaigns(): Promise<Campaign[]> {
    return await db
      .select()
      .from(campaigns)
      .where(eq(campaigns.status, 'pending'))
      .orderBy(campaigns.createdAt);
  }

  // Campaign email operations
  async createCampaignEmails(emails: InsertCampaignEmail[]): Promise<CampaignEmail[]> {
    if (emails.length === 0) return [];
    return await db.insert(campaignEmails).values(emails).returning();
  }

  async createCampaignEmailsBatched(emails: InsertCampaignEmail[], batchSize: number = 500): Promise<number> {
    if (emails.length === 0) return 0;
    
    let insertedCount = 0;
    for (let i = 0; i < emails.length; i += batchSize) {
      const batch = emails.slice(i, i + batchSize);
      await db.insert(campaignEmails).values(batch);
      insertedCount += batch.length;
    }
    return insertedCount;
  }

  async clearCampaignEmails(campaignId: string): Promise<void> {
    await db.delete(campaignEmails).where(eq(campaignEmails.campaignId, campaignId));
  }

  async resetCampaignEmailsToRetry(campaignId: string): Promise<number> {
    const result = await db
      .update(campaignEmails)
      .set({ status: 'pending', errorMessage: null, processedAt: null })
      .where(and(
        eq(campaignEmails.campaignId, campaignId),
        eq(campaignEmails.status, 'failed')
      ))
      .returning();
    return result.length;
  }

  async getPendingCampaignEmails(campaignId: string, limit: number = 10): Promise<CampaignEmail[]> {
    return await db
      .select()
      .from(campaignEmails)
      .where(and(
        eq(campaignEmails.campaignId, campaignId),
        eq(campaignEmails.status, 'pending')
      ))
      .limit(limit);
  }

  async updateCampaignEmailStatus(id: string, status: string, sentEmailId?: string, errorMessage?: string): Promise<void> {
    await db
      .update(campaignEmails)
      .set({
        status,
        sentEmailId,
        errorMessage,
        processedAt: new Date(),
      })
      .where(eq(campaignEmails.id, id));
  }

  async getCampaignEmailStats(campaignId: string): Promise<{ pending: number; sent: number; failed: number }> {
    const results = await db
      .select({
        status: campaignEmails.status,
        count: sql<number>`count(*)::int`,
      })
      .from(campaignEmails)
      .where(eq(campaignEmails.campaignId, campaignId))
      .groupBy(campaignEmails.status);

    const stats = { pending: 0, sent: 0, failed: 0 };
    results.forEach((r) => {
      if (r.status === 'pending') stats.pending = r.count;
      if (r.status === 'sent') stats.sent = r.count;
      if (r.status === 'failed') stats.failed = r.count;
    });

    return stats;
  }

  async getCampaignEmailsByCampaign(campaignId: string, limit: number = 100, offset: number = 0): Promise<CampaignEmail[]> {
    return await db
      .select()
      .from(campaignEmails)
      .where(eq(campaignEmails.campaignId, campaignId))
      .orderBy(desc(campaignEmails.processedAt))
      .limit(limit)
      .offset(offset);
  }
}

export const storage = new DatabaseStorage();
