#!/bin/bash

set -e

echo "=========================================="
echo "  Hackure Email Platform - Setup Script"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed. Please install Node.js 18+ first."
    exit 1
fi

echo "Node.js version: $(node -v)"
echo "npm version: $(npm -v)"
echo ""

# Install dependencies
echo "[1/7] Installing npm dependencies..."
npm install

# Install pm2 globally if not present
if ! command -v pm2 &> /dev/null; then
    echo "[2/7] Installing pm2 globally..."
    npm install -g pm2
else
    echo "[2/7] pm2 is already installed"
fi

# Prompt for environment variables
echo ""
echo "[3/7] Configuring environment variables..."
echo "Please enter the following credentials:"
echo ""

read -p "AZURE_CLIENT_ID: " AZURE_CLIENT_ID
read -p "AZURE_TENANT_ID: " AZURE_TENANT_ID
read -s -p "AZURE_CLIENT_SECRET: " AZURE_CLIENT_SECRET
echo ""
read -p "CONFIG_EMAIL (e.g., sales@hackure.in): " CONFIG_EMAIL
read -p "DATABASE_URL (PostgreSQL connection string): " DATABASE_URL
read -p "SESSION_SECRET (press Enter to auto-generate): " SESSION_SECRET

# Auto-generate session secret if not provided
if [ -z "$SESSION_SECRET" ]; then
    SESSION_SECRET=$(openssl rand -hex 32)
    echo "Session secret auto-generated"
fi

# Create .env file
echo ""
echo "[4/7] Creating .env file..."
cat > .env << EOF
# Azure AD Configuration (Microsoft Graph API)
AZURE_CLIENT_ID=${AZURE_CLIENT_ID}
AZURE_TENANT_ID=${AZURE_TENANT_ID}
AZURE_CLIENT_SECRET=${AZURE_CLIENT_SECRET}

# Email Configuration
CONFIG_EMAIL=${CONFIG_EMAIL}

# Database Configuration
DATABASE_URL=${DATABASE_URL}

# Application Configuration
PORT=5050
NODE_ENV=production
SESSION_SECRET=${SESSION_SECRET}
EOF

echo ".env file created successfully"

# Export environment variables for current session
export DATABASE_URL="${DATABASE_URL}"
export NODE_ENV=production

# Run database migrations
echo ""
echo "[5/7] Setting up database..."
npm run db:push

# Seed database
echo ""
echo "Seeding database with initial data..."
npx tsx server/seed.ts

# Build the application
echo ""
echo "[6/7] Building application for production..."
npm run build

# Create pm2 ecosystem file
echo ""
echo "[7/7] Starting application with pm2..."

cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'hackure-email-platform',
    script: 'dist/index.js',
    cwd: '${PWD}',
    env: {
      NODE_ENV: 'production',
      PORT: 5050
    },
    node_args: '--env-file=.env',
    watch: false,
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    max_memory_restart: '1G',
    error_file: 'logs/error.log',
    out_file: 'logs/output.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    merge_logs: true
  }]
};
EOF

# Create logs directory
mkdir -p logs

# Stop existing instance if running
pm2 delete hackure-email-platform 2>/dev/null || true

# Start with pm2
pm2 start ecosystem.config.cjs

# Save pm2 process list
pm2 save

echo ""
echo "=========================================="
echo "  Setup Complete!"
echo "=========================================="
echo ""
echo "Application is running on http://localhost:5050"
echo ""
echo "Useful pm2 commands:"
echo "  pm2 logs hackure-email-platform   - View logs"
echo "  pm2 status                         - Check status"
echo "  pm2 restart hackure-email-platform - Restart app"
echo "  pm2 stop hackure-email-platform    - Stop app"
echo "  pm2 startup                        - Enable startup on boot"
echo ""
echo "Log files location: ./logs/"
echo ""
echo "Default login credentials:"
echo "  Admin: admin@hackure.in / Test@1234"
echo "  Sales: sales@hackure.in / Test@1234"
echo ""
echo "Note: Change these passwords after first login!"
echo ""
