import { useEffect, useRef, useCallback, useState } from "react";
import { queryClient } from "@/lib/queryClient";

type ConnectionStatus = "connecting" | "connected" | "disconnected" | "error";

export function useRealtimeEmails() {
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>("disconnected");
  const [lastSync, setLastSync] = useState<Date | null>(null);

  const invalidateEmailQueries = useCallback(() => {
    // Use exact: false to invalidate all paginated variations of these queries
    queryClient.invalidateQueries({ queryKey: ["/api/emails/received"], exact: false });
    queryClient.invalidateQueries({ queryKey: ["/api/emails"], exact: false });
    queryClient.invalidateQueries({ queryKey: ["/api/email-threads"], exact: false });
    queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"], exact: false });
    queryClient.invalidateQueries({ queryKey: ["/api/sales/stats"], exact: false });
    setLastSync(new Date());
  }, []);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    setConnectionStatus("connecting");
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log("[WebSocket] Connected for real-time email updates");
      setConnectionStatus("connected");
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.event === "email_update") {
          console.log("[WebSocket] Email update received:", data);
          invalidateEmailQueries();
        }
      } catch (error) {
        console.error("[WebSocket] Error parsing message:", error);
      }
    };

    ws.onclose = () => {
      console.log("[WebSocket] Connection closed, will reconnect...");
      setConnectionStatus("disconnected");
      wsRef.current = null;

      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 3000);
    };

    ws.onerror = (error) => {
      console.error("[WebSocket] Error:", error);
      setConnectionStatus("error");
    };

    wsRef.current = ws;
  }, [invalidateEmailQueries]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }, []);

  useEffect(() => {
    connect();

    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    connectionStatus,
    lastSync,
    reconnect: connect,
  };
}
