import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Send,
  Database,
  FileText,
  Settings,
  Activity,
  Users,
  LogOut,
  Inbox,
  MailOpen,
  MessagesSquare,
  Megaphone,
} from "lucide-react";
import hackureLogo from "@assets/main logo_1764075526162.png";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  SidebarHeader,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export function AppSidebar() {
  const [location] = useLocation();
  const { user, isAdmin } = useAuth();
  const { toast } = useToast();

  const adminItems = [
    {
      title: "Dashboard",
      url: "/",
      icon: LayoutDashboard,
    },
    {
      title: "Send Email",
      url: "/send",
      icon: Send,
    },
    {
      title: "Email Templates",
      url: "/templates",
      icon: FileText,
    },
    {
      title: "Datasets",
      url: "/datasets",
      icon: Database,
    },
    {
      title: "Campaigns",
      url: "/campaigns",
      icon: Megaphone,
    },
    {
      title: "Inbox",
      url: "/inbox",
      icon: Inbox,
    },
    {
      title: "Sent Emails",
      url: "/sent",
      icon: MailOpen,
    },
    {
      title: "All Threads",
      url: "/threads",
      icon: MessagesSquare,
    },
    {
      title: "Users",
      url: "/users",
      icon: Users,
    },
    {
      title: "Activity Logs",
      url: "/logs",
      icon: Activity,
    },
    {
      title: "Settings",
      url: "/settings",
      icon: Settings,
    },
  ];

  const salesItems = [
    {
      title: "Dashboard",
      url: "/",
      icon: LayoutDashboard,
    },
    {
      title: "Send Email",
      url: "/send",
      icon: Send,
    },
    {
      title: "Inbox",
      url: "/inbox",
      icon: Inbox,
    },
    {
      title: "Sent Emails",
      url: "/sent",
      icon: MailOpen,
    },
    {
      title: "My Threads",
      url: "/threads",
      icon: MessagesSquare,
    },
    {
      title: "Datasets",
      url: "/datasets",
      icon: Database,
    },
    {
      title: "Campaigns",
      url: "/campaigns",
      icon: Megaphone,
    },
    {
      title: "Settings",
      url: "/settings",
      icon: Settings,
    },
  ];

  const items = isAdmin ? adminItems : salesItems;

  const getInitials = () => {
    if (user?.email) {
      return user.email.substring(0, 2).toUpperCase();
    }
    return "U";
  };

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-3">
          <img
            src={hackureLogo}
            alt="Hackure"
            className="h-10 w-auto object-contain"
            data-testid="img-hackure-logo"
          />
          <Badge
            variant={isAdmin ? "default" : "secondary"}
            className="w-fit text-xs"
            data-testid={`badge-role-${user?.role}`}
          >
            {user?.role?.toUpperCase()}
          </Badge>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    data-testid={`link-nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <Link href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-4">
        <div className="flex items-center gap-3 rounded-md border border-sidebar-border bg-sidebar-accent p-3">
          <Avatar className="h-9 w-9" data-testid="avatar-user">
            <AvatarFallback>{getInitials()}</AvatarFallback>
          </Avatar>
          <div className="flex flex-1 flex-col overflow-hidden">
            <span className="truncate text-sm font-medium" data-testid="text-user-name">
              {user?.email || "User"}
            </span>
            <span className="truncate text-xs text-muted-foreground" data-testid="text-user-email">
              {user?.role || "user"}
            </span>
          </div>
        </div>
        <Button
          variant="ghost"
          className="mt-2 w-full justify-start"
          onClick={async () => {
            try {
              const res = await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
              if (res.ok) {
                window.location.href = "/";
              } else {
                toast({
                  title: "Logout failed",
                  description: "Could not log out. Please try again.",
                  variant: "destructive",
                });
              }
            } catch (error) {
              console.error("Logout error:", error);
              toast({
                title: "Logout failed",
                description: "Network error. Please check your connection and try again.",
                variant: "destructive",
              });
            }
          }}
          data-testid="button-logout"
        >
          <LogOut className="h-4 w-4" />
          <span>Log Out</span>
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
