import { useRealtimeEmails } from "@/hooks/use-realtime-emails";
import { Badge } from "@/components/ui/badge";
import { Wifi, WifiOff, RefreshCw } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export function RealtimeSync() {
  const { connectionStatus, lastSync } = useRealtimeEmails();

  const statusIcon = {
    connected: <Wifi className="h-3 w-3" />,
    connecting: <RefreshCw className="h-3 w-3 animate-spin" />,
    disconnected: <WifiOff className="h-3 w-3" />,
    error: <WifiOff className="h-3 w-3" />,
  };

  const statusColor = {
    connected: "bg-green-500/10 text-green-600 dark:text-green-400",
    connecting: "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",
    disconnected: "bg-gray-500/10 text-gray-600 dark:text-gray-400",
    error: "bg-red-500/10 text-red-600 dark:text-red-400",
  };

  const statusText = {
    connected: "Live sync active",
    connecting: "Connecting...",
    disconnected: "Reconnecting...",
    error: "Connection error",
  };

  const lastSyncText = lastSync
    ? `Last synced: ${lastSync.toLocaleTimeString()}`
    : "Waiting for sync...";

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Badge 
          variant="outline" 
          className={`gap-1.5 cursor-default ${statusColor[connectionStatus]}`}
          data-testid="badge-sync-status"
        >
          {statusIcon[connectionStatus]}
          <span className="text-xs">Live</span>
        </Badge>
      </TooltipTrigger>
      <TooltipContent>
        <div className="text-xs">
          <p className="font-medium">{statusText[connectionStatus]}</p>
          <p className="text-muted-foreground">{lastSyncText}</p>
          <p className="text-muted-foreground mt-1">Emails sync every minute</p>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}
