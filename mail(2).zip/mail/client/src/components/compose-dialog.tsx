import { useState, useEffect, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Send, Paperclip, X, Image as ImageIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { RichTextEditor } from "@/components/rich-text-editor";

interface InlineImage {
  contentId: string;
  contentBytes: string;
  contentType: string;
  name: string;
}

interface ComposeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: "compose" | "reply" | "forward";
  originalEmail?: {
    id: string;
    senderEmail?: string;
    recipientEmail?: string;
    subject: string;
    body: string;
    senderName?: string;
    recipientName?: string;
  };
}

export function ComposeDialog({ open, onOpenChange, mode, originalEmail }: ComposeDialogProps) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const getDefaultRecipient = () => {
    if (mode === "reply") {
      return originalEmail?.senderEmail || originalEmail?.recipientEmail || "";
    }
    return "";
  };

  const getDefaultSubject = () => {
    if (!originalEmail) return "";
    
    if (mode === "reply") {
      return originalEmail.subject.startsWith("Re: ") 
        ? originalEmail.subject 
        : `Re: ${originalEmail.subject}`;
    }
    
    if (mode === "forward") {
      return originalEmail.subject.startsWith("Fwd: ") 
        ? originalEmail.subject 
        : `Fwd: ${originalEmail.subject}`;
    }
    
    return "";
  };

  const stripHtml = (html: string): string => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.body.textContent || "";
  };

  const getDefaultBody = () => {
    if (!originalEmail) return "";
    
    const plainTextBody = originalEmail.body?.startsWith("<") 
      ? stripHtml(originalEmail.body) 
      : originalEmail.body;
    
    const separator = "<br><br>------- Original Message -------<br>";
    const originalContent = `From: ${originalEmail.senderName || originalEmail.senderEmail || originalEmail.recipientName || originalEmail.recipientEmail || "Unknown"}<br>Subject: ${originalEmail.subject}<br><br>${plainTextBody.replace(/\n/g, '<br>')}`;
    
    if (mode === "reply" || mode === "forward") {
      return `<p></p>${separator}${originalContent}`;
    }
    
    return "";
  };

  const [recipient, setRecipient] = useState(getDefaultRecipient());
  const [subject, setSubject] = useState(getDefaultSubject());
  const [body, setBody] = useState(getDefaultBody());
  const [attachments, setAttachments] = useState<File[]>([]);
  const [inlineImages, setInlineImages] = useState<InlineImage[]>([]);

  useEffect(() => {
    if (open) {
      setRecipient(getDefaultRecipient());
      setSubject(getDefaultSubject());
      setBody(getDefaultBody());
      setAttachments([]);
      setInlineImages([]);
    }
  }, [open, mode, originalEmail?.id]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    const newFiles = Array.from(files);
    const totalSize = [...attachments, ...newFiles].reduce((sum, f) => sum + f.size, 0);
    
    if (totalSize > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Total attachment size cannot exceed 10MB",
        variant: "destructive",
      });
      return;
    }
    
    setAttachments(prev => [...prev, ...newFiles]);
    e.target.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const sendEmailMutation = useMutation({
    mutationFn: async () => {
      const formData = new FormData();
      formData.append('to', recipient);
      formData.append('subject', subject);
      formData.append('body', body);
      formData.append('mode', mode);
      if (originalEmail?.id) {
        formData.append('originalEmailId', originalEmail.id);
      }
      
      attachments.forEach(file => {
        formData.append('attachments', file);
      });
      
      if (inlineImages.length > 0) {
        formData.append('inlineImages', JSON.stringify(inlineImages));
      }
      
      const response = await fetch('/api/emails/send-single', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to send email');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emails/received"] });
      queryClient.invalidateQueries({ queryKey: ["/api/email-threads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sales/stats"] });
      toast({
        title: "Success",
        description: `Email ${mode === "compose" ? "sent" : mode === "reply" ? "replied" : "forwarded"} successfully`,
      });
      onOpenChange(false);
      setRecipient("");
      setSubject("");
      setBody("");
      setAttachments([]);
      setInlineImages([]);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || `Failed to ${mode} email`,
        variant: "destructive",
      });
    },
  });

  const handleSend = () => {
    const plainText = new DOMParser().parseFromString(body, 'text/html').body.textContent || "";
    if (!recipient || !subject || !plainText.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }
    sendEmailMutation.mutate();
  };

  const getDialogTitle = () => {
    if (mode === "reply") return "Reply to Email";
    if (mode === "forward") return "Forward Email";
    return "Compose Email";
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] flex flex-col overflow-hidden">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle>{getDialogTitle()}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 flex-1 overflow-y-auto min-h-0">
          <div>
            <Label htmlFor="recipient">To</Label>
            <Input
              id="recipient"
              type="email"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="recipient@example.com"
              disabled={mode === "reply" && !!recipient}
              data-testid="input-recipient"
            />
          </div>
          <div>
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Email subject"
              data-testid="input-subject"
            />
          </div>
          
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Label>Attachments</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                data-testid="button-add-attachment"
              >
                <Paperclip className="h-4 w-4 mr-1" />
                Add File
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileSelect}
                className="hidden"
                data-testid="input-file-attachment"
              />
            </div>
            {attachments.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {attachments.map((file, index) => (
                  <Badge key={index} variant="secondary" className="gap-1 pr-1">
                    <Paperclip className="h-3 w-3" />
                    <span className="max-w-[150px] truncate">{file.name}</span>
                    <span className="text-muted-foreground">({formatFileSize(file.size)})</span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 ml-1"
                      onClick={() => removeAttachment(index)}
                      data-testid={`button-remove-attachment-${index}`}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
            {inlineImages.length > 0 && (
              <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                <ImageIcon className="h-4 w-4" />
                <span>{inlineImages.length} embedded image{inlineImages.length > 1 ? 's' : ''}</span>
              </div>
            )}
          </div>

          <div className="flex flex-col flex-1 min-h-0">
            <Label className="mb-2">Message</Label>
            <RichTextEditor
              content={body}
              onChange={setBody}
              onInlineImagesChange={setInlineImages}
              placeholder="Write your message..."
              minHeight="200px"
              className="flex-1"
            />
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} data-testid="button-cancel">
            Cancel
          </Button>
          <Button
            onClick={handleSend}
            disabled={!recipient || !subject || sendEmailMutation.isPending}
            data-testid="button-send-email"
          >
            {sendEmailMutation.isPending ? (
              "Sending..."
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Send
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
