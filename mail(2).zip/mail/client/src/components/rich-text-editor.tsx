import { useEditor, EditorContent, Editor } from '@tiptap/react';
import { NodeSelection } from '@tiptap/pm/state';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import { TextStyle } from '@tiptap/extension-text-style';
import Color from '@tiptap/extension-color';
import Image from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Bold,
  Italic,
  Underline as UnderlineIcon,
  Strikethrough,
  List,
  ListOrdered,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Link as LinkIcon,
  Image as ImageIcon,
  Palette,
  Undo,
  Redo,
  Heading1,
  Heading2,
  Minus,
  Plus,
} from 'lucide-react';

export interface InlineImage {
  contentId: string;
  contentBytes: string;
  contentType: string;
  name: string;
}

interface RichTextEditorProps {
  content?: string;
  onChange?: (html: string) => void;
  onInlineImagesChange?: (images: InlineImage[]) => void;
  placeholder?: string;
  className?: string;
  minHeight?: string;
}

const ResizableImage = Image.extend({
  addAttributes() {
    return {
      src: { default: null },
      alt: { default: null },
      title: { default: null },
      width: {
        default: '300px',
        parseHTML: (element: HTMLElement) => element.getAttribute('width') || element.style.width || '300px',
        renderHTML: (attributes: Record<string, string>) => {
          if (!attributes.width) return {};
          return { width: attributes.width, style: `width: ${attributes.width}; max-width: 100%;` };
        },
      },
      'data-content-id': {
        default: null,
        parseHTML: (element: HTMLElement) => element.getAttribute('data-content-id'),
        renderHTML: (attributes: Record<string, string>) => {
          if (!attributes['data-content-id']) return {};
          return { 'data-content-id': attributes['data-content-id'] };
        },
      },
    };
  },
});

function ToolbarButton({ 
  onClick, 
  isActive = false, 
  disabled = false,
  children,
  title,
}: { 
  onClick: () => void; 
  isActive?: boolean; 
  disabled?: boolean;
  children: React.ReactNode;
  title?: string;
}) {
  return (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      onClick={onClick}
      disabled={disabled}
      className={`h-8 w-8 ${isActive ? 'bg-accent' : ''}`}
      title={title}
    >
      {children}
    </Button>
  );
}

function EditorToolbar({ 
  editor, 
  onImageInsert,
  selectedImageWidth,
  onResizeImage,
}: { 
  editor: Editor; 
  onImageInsert?: () => void;
  selectedImageWidth: number | null;
  onResizeImage: (delta: number) => void;
}) {
  const [linkUrl, setLinkUrl] = useState('');
  const [linkOpen, setLinkOpen] = useState(false);
  const [colorOpen, setColorOpen] = useState(false);

  const colors = [
    '#000000', '#374151', '#6b7280', '#9ca3af',
    '#ef4444', '#f97316', '#eab308', '#22c55e',
    '#3b82f6', '#8b5cf6', '#ec4899', '#14b8a6',
  ];

  const setLink = useCallback(() => {
    if (linkUrl) {
      editor.chain().focus().extendMarkRange('link').setLink({ href: linkUrl }).run();
    } else {
      editor.chain().focus().extendMarkRange('link').unsetLink().run();
    }
    setLinkOpen(false);
    setLinkUrl('');
  }, [editor, linkUrl]);

  return (
    <div className="flex flex-wrap items-center gap-0.5 p-1 border-b bg-muted/30">
      <ToolbarButton
        onClick={() => editor.chain().focus().undo().run()}
        disabled={!editor.can().undo()}
        title="Undo"
      >
        <Undo className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().redo().run()}
        disabled={!editor.can().redo()}
        title="Redo"
      >
        <Redo className="h-4 w-4" />
      </ToolbarButton>

      <Separator orientation="vertical" className="h-6 mx-1" />

      <ToolbarButton
        onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
        isActive={editor.isActive('heading', { level: 1 })}
        title="Heading 1"
      >
        <Heading1 className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
        isActive={editor.isActive('heading', { level: 2 })}
        title="Heading 2"
      >
        <Heading2 className="h-4 w-4" />
      </ToolbarButton>

      <Separator orientation="vertical" className="h-6 mx-1" />

      <ToolbarButton
        onClick={() => editor.chain().focus().toggleBold().run()}
        isActive={editor.isActive('bold')}
        title="Bold"
      >
        <Bold className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleItalic().run()}
        isActive={editor.isActive('italic')}
        title="Italic"
      >
        <Italic className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleUnderline().run()}
        isActive={editor.isActive('underline')}
        title="Underline"
      >
        <UnderlineIcon className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleStrike().run()}
        isActive={editor.isActive('strike')}
        title="Strikethrough"
      >
        <Strikethrough className="h-4 w-4" />
      </ToolbarButton>

      <Separator orientation="vertical" className="h-6 mx-1" />

      <Popover open={colorOpen} onOpenChange={setColorOpen}>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="icon" className="h-8 w-8" title="Text Color">
            <Palette className="h-4 w-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-2">
          <div className="grid grid-cols-4 gap-1">
            {colors.map((color) => (
              <button
                key={color}
                className="w-6 h-6 rounded border hover:scale-110 transition-transform"
                style={{ backgroundColor: color }}
                onClick={() => {
                  editor.chain().focus().setColor(color).run();
                  setColorOpen(false);
                }}
              />
            ))}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="w-full mt-2"
            onClick={() => {
              editor.chain().focus().unsetColor().run();
              setColorOpen(false);
            }}
          >
            Reset Color
          </Button>
        </PopoverContent>
      </Popover>

      <Separator orientation="vertical" className="h-6 mx-1" />

      <ToolbarButton
        onClick={() => editor.chain().focus().toggleBulletList().run()}
        isActive={editor.isActive('bulletList')}
        title="Bullet List"
      >
        <List className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().toggleOrderedList().run()}
        isActive={editor.isActive('orderedList')}
        title="Numbered List"
      >
        <ListOrdered className="h-4 w-4" />
      </ToolbarButton>

      <Separator orientation="vertical" className="h-6 mx-1" />

      <ToolbarButton
        onClick={() => editor.chain().focus().setTextAlign('left').run()}
        isActive={editor.isActive({ textAlign: 'left' })}
        title="Align Left"
      >
        <AlignLeft className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().setTextAlign('center').run()}
        isActive={editor.isActive({ textAlign: 'center' })}
        title="Align Center"
      >
        <AlignCenter className="h-4 w-4" />
      </ToolbarButton>
      <ToolbarButton
        onClick={() => editor.chain().focus().setTextAlign('right').run()}
        isActive={editor.isActive({ textAlign: 'right' })}
        title="Align Right"
      >
        <AlignRight className="h-4 w-4" />
      </ToolbarButton>

      <Separator orientation="vertical" className="h-6 mx-1" />

      <Popover open={linkOpen} onOpenChange={setLinkOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className={`h-8 w-8 ${editor.isActive('link') ? 'bg-accent' : ''}`}
            title="Insert Link"
          >
            <LinkIcon className="h-4 w-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80">
          <div className="space-y-2">
            <Label htmlFor="link-url">URL</Label>
            <Input
              id="link-url"
              placeholder="https://example.com"
              value={linkUrl}
              onChange={(e) => setLinkUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && setLink()}
            />
            <div className="flex justify-end gap-2">
              {editor.isActive('link') && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    editor.chain().focus().unsetLink().run();
                    setLinkOpen(false);
                  }}
                >
                  Remove
                </Button>
              )}
              <Button size="sm" onClick={setLink}>
                Apply
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      {onImageInsert && (
        <ToolbarButton onClick={onImageInsert} title="Insert Image">
          <ImageIcon className="h-4 w-4" />
        </ToolbarButton>
      )}

      {selectedImageWidth !== null && (
        <>
          <Separator orientation="vertical" className="h-6 mx-1" />
          <div className="flex items-center gap-1 bg-accent/50 rounded px-1">
            <ToolbarButton onClick={() => onResizeImage(-50)} title="Decrease Size">
              <Minus className="h-4 w-4" />
            </ToolbarButton>
            <span className="text-xs min-w-[50px] text-center">{selectedImageWidth}px</span>
            <ToolbarButton onClick={() => onResizeImage(50)} title="Increase Size">
              <Plus className="h-4 w-4" />
            </ToolbarButton>
          </div>
        </>
      )}
    </div>
  );
}

export function RichTextEditor({
  content = '',
  onChange,
  onInlineImagesChange,
  placeholder = 'Write your message...',
  className = '',
  minHeight = '200px',
}: RichTextEditorProps) {
  const inlineImagesRef = useRef<Map<string, InlineImage>>(new Map());
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedImageWidth, setSelectedImageWidth] = useState<number | null>(null);

  const generateContentId = () => {
    return `img_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  };

  const addInlineImage = useCallback((image: InlineImage) => {
    inlineImagesRef.current.set(image.contentId, image);
    onInlineImagesChange?.(Array.from(inlineImagesRef.current.values()));
  }, [onInlineImagesChange]);

  const syncInlineImages = useCallback((editor: Editor) => {
    const currentImageIds = new Set<string>();
    editor.state.doc.descendants((node) => {
      if (node.type.name === 'image' && node.attrs['data-content-id']) {
        currentImageIds.add(node.attrs['data-content-id']);
      }
    });

    let changed = false;
    const keysToCheck = Array.from(inlineImagesRef.current.keys());
    for (const contentId of keysToCheck) {
      if (!currentImageIds.has(contentId)) {
        inlineImagesRef.current.delete(contentId);
        changed = true;
      }
    }

    if (changed) {
      onInlineImagesChange?.(Array.from(inlineImagesRef.current.values()));
    }
  }, [onInlineImagesChange]);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3] },
      }),
      Underline,
      TextAlign.configure({
        types: ['heading', 'paragraph'],
      }),
      TextStyle,
      Color,
      ResizableImage.configure({
        inline: false,
        allowBase64: true,
        HTMLAttributes: {
          class: 'rounded cursor-pointer',
        },
      }),
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          class: 'text-primary underline',
        },
      }),
    ],
    content,
    editorProps: {
      attributes: {
        class: 'prose prose-sm dark:prose-invert max-w-none focus:outline-none min-h-full p-3',
        style: `min-height: ${minHeight}`,
      },
      handlePaste: (view, event) => {
        const items = event.clipboardData?.items;
        if (!items) return false;

        for (const item of Array.from(items)) {
          if (item.type.startsWith('image/')) {
            event.preventDefault();
            const file = item.getAsFile();
            if (!file) continue;

            const reader = new FileReader();
            reader.onload = (e) => {
              const base64 = e.target?.result as string;
              if (!base64 || !editor) return;

              const base64Data = base64.split(',')[1];
              const contentId = generateContentId();

              addInlineImage({
                contentId,
                contentBytes: base64Data,
                contentType: file.type,
                name: `pasted_image_${contentId}.${file.type.split('/')[1] || 'png'}`,
              });

              editor.chain().focus().setImage({ 
                src: base64,
                alt: 'Pasted image',
              } as any).run();

              // Update the image with content-id attribute
              setTimeout(() => {
                const { state, view } = editor;
                state.doc.descendants((node, pos) => {
                  if (node.type.name === 'image' && node.attrs.src === base64) {
                    view.dispatch(
                      state.tr.setNodeMarkup(pos, undefined, {
                        ...node.attrs,
                        'data-content-id': contentId,
                        width: '300px',
                      })
                    );
                    return false;
                  }
                });
              }, 10);
            };
            reader.readAsDataURL(file);
            return true;
          }
        }
        return false;
      },
    },
    onUpdate: ({ editor }) => {
      // Sync inline images to remove deleted ones
      syncInlineImages(editor);
      
      const html = editor.getHTML();
      
      // Convert local base64 src to cid: references for output
      // Only convert if we have the actual image data
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const images = doc.querySelectorAll('img[data-content-id]');
      images.forEach(img => {
        const contentId = img.getAttribute('data-content-id');
        if (contentId && inlineImagesRef.current.has(contentId)) {
          // Only set cid: if we have the image data to send
          img.setAttribute('src', `cid:${contentId}`);
        }
      });
      
      onChange?.(doc.body.innerHTML);
    },
    onSelectionUpdate: ({ editor }) => {
      const { selection } = editor.state;
      if (selection instanceof NodeSelection && selection.node.type.name === 'image') {
        const width = selection.node.attrs.width;
        const numWidth = parseInt(width) || 300;
        setSelectedImageWidth(numWidth);
      } else {
        setSelectedImageWidth(null);
      }
    },
  });

  const resizeSelectedImage = useCallback((delta: number) => {
    if (!editor) return;
    
    const { selection, tr } = editor.state;
    if (selection instanceof NodeSelection && selection.node.type.name === 'image') {
      const node = selection.node;
      const currentWidth = parseInt(node.attrs.width) || 300;
      const newWidth = Math.max(50, Math.min(800, currentWidth + delta));
      
      // Preserve all existing attributes and only update width
      const newAttrs = {
        ...node.attrs,
        width: `${newWidth}px`,
      };
      
      // Use setNodeMarkup to preserve all attributes including src and data-content-id
      const pos = selection.from;
      editor.view.dispatch(
        tr.setNodeMarkup(pos, undefined, newAttrs)
      );
      
      setSelectedImageWidth(newWidth);
    }
  }, [editor]);

  const handleImageFromFile = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editor) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (!base64) return;

      const base64Data = base64.split(',')[1];
      const contentId = generateContentId();

      addInlineImage({
        contentId,
        contentBytes: base64Data,
        contentType: file.type,
        name: file.name,
      });

      editor.chain().focus().setImage({
        src: base64,
        alt: file.name,
      } as any).run();

      // Update the image with content-id attribute
      setTimeout(() => {
        const { state, view } = editor;
        state.doc.descendants((node, pos) => {
          if (node.type.name === 'image' && node.attrs.src === base64) {
            view.dispatch(
              state.tr.setNodeMarkup(pos, undefined, {
                ...node.attrs,
                'data-content-id': contentId,
                width: '300px',
              })
            );
            return false;
          }
        });
      }, 10);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  }, [editor, addInlineImage]);

  useEffect(() => {
    if (editor && content && !editor.isFocused) {
      const currentContent = editor.getHTML();
      if (currentContent !== content && content !== '<p></p>') {
        editor.commands.setContent(content);
      }
    }
  }, [content, editor]);

  if (!editor) {
    return null;
  }

  return (
    <div className={`border rounded-md overflow-hidden bg-background ${className}`}>
      <EditorToolbar 
        editor={editor} 
        onImageInsert={onInlineImagesChange ? handleImageFromFile : undefined}
        selectedImageWidth={selectedImageWidth}
        onResizeImage={resizeSelectedImage}
      />
      <div className="relative" style={{ minHeight }}>
        <EditorContent 
          editor={editor} 
          className="overflow-y-auto"
          style={{ minHeight, maxHeight: '400px' }}
        />
        {editor.isEmpty && (
          <p className="absolute top-3 left-3 text-muted-foreground pointer-events-none">
            {placeholder}
          </p>
        )}
      </div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
}
