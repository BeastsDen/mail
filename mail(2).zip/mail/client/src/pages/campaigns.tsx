import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Plus, Play, Pause, Square, Trash2, Eye, Clock, Calendar, ChevronLeft, ChevronRight, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Campaign } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";

interface PaginatedCampaigns {
  campaigns: Campaign[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

interface CampaignWithStats extends Campaign {
  stats?: {
    pending: number;
    sent: number;
    failed: number;
  };
}


export default function Campaigns() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState<CampaignWithStats | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  const { data: paginatedData, isLoading, refetch } = useQuery<PaginatedCampaigns>({
    queryKey: ["/api/campaigns", { page: currentPage }],
    queryFn: async () => {
      const res = await fetch(`/api/campaigns?page=${currentPage}`);
      if (!res.ok) throw new Error("Failed to fetch campaigns");
      return res.json();
    },
    enabled: isAuthenticated && !authLoading,
    refetchInterval: 10000,
  });

  const campaigns = paginatedData?.campaigns || [];
  const totalPages = paginatedData?.totalPages || 1;

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const startMutation = useMutation({
    mutationFn: async (id: string) => apiRequest("POST", `/api/campaigns/${id}/start`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({ title: "Campaign started" });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to start campaign", description: error.message, variant: "destructive" });
    },
  });

  const pauseMutation = useMutation({
    mutationFn: async (id: string) => apiRequest("POST", `/api/campaigns/${id}/pause`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({ title: "Campaign paused" });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to pause campaign", description: error.message, variant: "destructive" });
    },
  });

  const stopMutation = useMutation({
    mutationFn: async (id: string) => apiRequest("POST", `/api/campaigns/${id}/stop`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({ title: "Campaign stopped" });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to stop campaign", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => apiRequest("DELETE", `/api/campaigns/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      toast({ title: "Campaign deleted" });
      setIsDetailDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({ title: "Failed to delete campaign", description: error.message, variant: "destructive" });
    },
  });

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      pending: "secondary",
      running: "default",
      paused: "outline",
      completed: "secondary",
      finished: "default",
      stopped: "destructive",
    };
    const labels: Record<string, string> = {
      pending: "Pending",
      running: "Running",
      paused: "Paused",
      completed: "Completed",
      finished: "Finished",
      stopped: "Stopped",
    };
    return <Badge variant={variants[status] || "secondary"}>{labels[status] || status}</Badge>;
  };

  const getProgress = (campaign: Campaign) => {
    if (campaign.totalContacts === 0) return 0;
    return Math.round(((campaign.sentCount + campaign.failedCount) / campaign.totalContacts) * 100);
  };

  const viewCampaignDetails = async (campaign: Campaign) => {
    try {
      const res = await fetch(`/api/campaigns/${campaign.id}`);
      if (!res.ok) throw new Error("Failed to fetch campaign details");
      const data = await res.json();
      setSelectedCampaign(data);
      setIsDetailDialogOpen(true);
    } catch (error) {
      toast({ title: "Failed to load campaign details", variant: "destructive" });
    }
  };

  if (authLoading) {
    return (
      <div className="p-6">
        <Skeleton className="h-10 w-64 mb-6" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Campaigns</h1>
        <Button onClick={() => setLocation("/send")}>
          <Plus className="mr-2 h-4 w-4" /> New Campaign
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : campaigns.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Calendar className="mx-auto h-12 w-12 mb-4 opacity-50" />
              <p>No campaigns yet. Create your first campaign to get started.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Progress</TableHead>
                  <TableHead>Schedule</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {campaigns.map((campaign) => (
                  <TableRow key={campaign.id}>
                    <TableCell className="font-medium">{campaign.name}</TableCell>
                    <TableCell>{getStatusBadge(campaign.status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress value={getProgress(campaign)} className="w-20 h-2" />
                        <span className="text-sm text-muted-foreground">
                          {campaign.sentCount}/{campaign.totalContacts}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {campaign.scheduledDays && campaign.scheduledDays.length > 0 ? (
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {campaign.scheduleStartTime} - {campaign.scheduleEndTime}
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-sm">Always</span>
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {campaign.createdAt ? new Date(campaign.createdAt).toLocaleDateString() : '-'}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        {campaign.status === 'pending' || campaign.status === 'paused' || campaign.status === 'stopped' ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => startMutation.mutate(campaign.id)}
                            disabled={startMutation.isPending}
                          >
                            <Play className="h-4 w-4 text-green-600" />
                          </Button>
                        ) : null}
                        {campaign.status === 'running' ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => pauseMutation.mutate(campaign.id)}
                            disabled={pauseMutation.isPending}
                          >
                            <Pause className="h-4 w-4 text-yellow-600" />
                          </Button>
                        ) : null}
                        {(campaign.status === 'running' || campaign.status === 'paused') ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => stopMutation.mutate(campaign.id)}
                            disabled={stopMutation.isPending}
                          >
                            <Square className="h-4 w-4 text-red-600" />
                          </Button>
                        ) : null}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => viewCampaignDetails(campaign)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
        {totalPages > 1 && (
          <CardFooter className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              Page {currentPage} of {totalPages}
            </p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardFooter>
        )}
      </Card>

      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{selectedCampaign?.name}</DialogTitle>
            <DialogDescription>
              Campaign details and progress
            </DialogDescription>
          </DialogHeader>
          {selectedCampaign && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Status</span>
                {getStatusBadge(selectedCampaign.status)}
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>{selectedCampaign.sentCount + selectedCampaign.failedCount} / {selectedCampaign.totalContacts}</span>
                </div>
                <Progress value={getProgress(selectedCampaign)} className="h-2" />
              </div>

              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-2xl font-bold text-green-600">{selectedCampaign.sentCount}</p>
                  <p className="text-xs text-muted-foreground">Sent</p>
                </div>
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-2xl font-bold text-red-600">{selectedCampaign.failedCount}</p>
                  <p className="text-xs text-muted-foreground">Failed</p>
                </div>
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-2xl font-bold">{selectedCampaign.stats?.pending || 0}</p>
                  <p className="text-xs text-muted-foreground">Pending</p>
                </div>
              </div>

              {selectedCampaign.scheduledDays && selectedCampaign.scheduledDays.length > 0 && (
                <div className="space-y-1">
                  <p className="text-sm font-medium">Schedule</p>
                  <p className="text-sm text-muted-foreground">
                    {selectedCampaign.scheduledDays.map(d => d.charAt(0).toUpperCase() + d.slice(1, 3)).join(', ')}
                    {selectedCampaign.scheduleStartTime && ` from ${selectedCampaign.scheduleStartTime} to ${selectedCampaign.scheduleEndTime}`}
                  </p>
                </div>
              )}

              {selectedCampaign.errorMessage && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm text-red-700">{selectedCampaign.errorMessage}</p>
                </div>
              )}

              <div className="text-xs text-muted-foreground space-y-1">
                <p>Created: {selectedCampaign.createdAt ? new Date(selectedCampaign.createdAt).toLocaleString() : '-'}</p>
                {selectedCampaign.startedAt && <p>Started: {new Date(selectedCampaign.startedAt).toLocaleString()}</p>}
                {selectedCampaign.completedAt && <p>Completed: {new Date(selectedCampaign.completedAt).toLocaleString()}</p>}
              </div>
            </div>
          )}
          <DialogFooter>
            {selectedCampaign && selectedCampaign.status !== 'running' && (
              <Button
                variant="destructive"
                onClick={() => deleteMutation.mutate(selectedCampaign.id)}
                disabled={deleteMutation.isPending}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete Campaign
              </Button>
            )}
            <Button variant="outline" onClick={() => setIsDetailDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
