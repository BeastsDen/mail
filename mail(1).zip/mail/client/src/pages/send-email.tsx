import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Send, Clock, Play, Pause, Square, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Dataset, EmailTemplate, DatasetContact } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";

type CampaignStatus = "idle" | "countdown" | "sending" | "paused" | "completed";

export default function SendEmail() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [selectedDatasetId, setSelectedDatasetId] = useState("");
  const [selectedTemplateId, setSelectedTemplateId] = useState("");
  const [delaySeconds, setDelaySeconds] = useState(5);
  const [preview, setPreview] = useState({ subject: "", body: "", recipientEmail: "", recipientName: "" });
  
  const [campaignStatus, setCampaignStatus] = useState<CampaignStatus>("idle");
  const [countdown, setCountdown] = useState(0);
  const [previewIndex, setPreviewIndex] = useState(0);
  const [sendIndex, setSendIndex] = useState(0);
  const [sentCount, setSentCount] = useState(0);
  
  const countdownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const campaignStatusRef = useRef<CampaignStatus>("idle");
  const sendIndexRef = useRef(0);
  const sentCountRef = useRef(0);
  const delaySecondsRef = useRef(5);
  const contactsRef = useRef<DatasetContact[]>([]);
  const isSendingRef = useRef(false);

  const { data: datasetsResponse, isLoading: datasetsLoading } = useQuery<{ datasets: Dataset[], total: number }>({
    queryKey: ["/api/datasets"],
    enabled: isAuthenticated && !authLoading,
  });

  const { data: templatesResponse, isLoading: templatesLoading } = useQuery<{ templates: EmailTemplate[], total: number }>({
    queryKey: ["/api/templates"],
    enabled: isAuthenticated && !authLoading,
  });

  const datasets = datasetsResponse?.datasets || [];
  const templates = templatesResponse?.templates || [];

  const { data: contacts, isLoading: contactsLoading } = useQuery<DatasetContact[]>({
    queryKey: ["/api/datasets", selectedDatasetId, "contacts"],
    queryFn: async () => {
      if (!selectedDatasetId) return [];
      const res = await fetch(`/api/datasets/${selectedDatasetId}/contacts`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch contacts");
      return res.json();
    },
    enabled: isAuthenticated && !authLoading && !!selectedDatasetId,
  });

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const replaceVariables = useCallback((text: string, contact: DatasetContact) => {
    let result = text;
    const customFields = (contact.customFields || {}) as Record<string, string>;
    
    const allFields: Record<string, string> = {
      name: contact.name || "",
      email: contact.email || "",
      company: contact.company || "",
      number: (contact as any).number || "",
      firstName: contact.name?.split(" ")[0] || "",
      lastName: contact.name?.split(" ").slice(1).join(" ") || "",
      ...customFields,
    };

    Object.entries(allFields).forEach(([key, value]) => {
      const regex = new RegExp(`\\{\\{${key}\\}\\}`, "gi");
      result = result.replace(regex, value || "");
    });

    return result;
  }, []);

  useEffect(() => {
    campaignStatusRef.current = campaignStatus;
  }, [campaignStatus]);

  useEffect(() => {
    sendIndexRef.current = sendIndex;
  }, [sendIndex]);

  useEffect(() => {
    sentCountRef.current = sentCount;
  }, [sentCount]);

  useEffect(() => {
    delaySecondsRef.current = delaySeconds;
  }, [delaySeconds]);

  useEffect(() => {
    contactsRef.current = contacts || [];
  }, [contacts]);

  const displayIndex = campaignStatus === "idle" 
    ? previewIndex 
    : campaignStatus === "completed" 
      ? Math.max(0, (contacts?.length || 1) - 1)
      : Math.min(sendIndex, (contacts?.length || 1) - 1);

  useEffect(() => {
    if (selectedTemplateId && templates && contacts && contacts.length > 0) {
      const template = templates.find((t) => t.id === selectedTemplateId);
      const contact = contacts[displayIndex] || contacts[0];
      
      if (template && contact) {
        const previewSubject = replaceVariables(template.subject, contact);
        const previewBody = replaceVariables(template.body, contact);

        setPreview({
          subject: previewSubject,
          body: previewBody,
          recipientEmail: contact.email,
          recipientName: contact.name || "",
        });
      }
    } else if (selectedTemplateId && templates) {
      const template = templates.find((t) => t.id === selectedTemplateId);
      if (template) {
        setPreview({
          subject: template.subject,
          body: template.body,
          recipientEmail: "",
          recipientName: "",
        });
      }
    }
  }, [selectedTemplateId, templates, contacts, displayIndex, replaceVariables, campaignStatus]);

  const clearTimers = useCallback(() => {
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }
  }, []);

  const sendNextEmail = useCallback(async () => {
    if (isSendingRef.current) {
      return;
    }
    
    if (campaignStatusRef.current !== "sending") {
      return;
    }

    const currentContacts = contactsRef.current;
    const currentIndex = sendIndexRef.current;
    const currentSentCount = sentCountRef.current;

    if (!currentContacts || currentIndex >= currentContacts.length) {
      clearTimers();
      isSendingRef.current = false;
      setCampaignStatus("completed");
      queryClient.invalidateQueries({ queryKey: ["/api/sales/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
      toast({
        title: "Campaign Complete",
        description: `Successfully sent ${currentSentCount} emails`,
      });
      return;
    }

    const contact = currentContacts[currentIndex];
    
    isSendingRef.current = true;
    
    try {
      const template = templates?.find((t) => t.id === selectedTemplateId);
      if (!template) throw new Error("Template not found");

      const subject = replaceVariables(template.subject, contact);
      const body = replaceVariables(template.body, contact);

      await apiRequest("POST", "/api/emails/send-single", {
        to: contact.email,
        subject,
        body,
        templateId: selectedTemplateId,
        datasetId: selectedDatasetId,
        contactId: contact.id,
      });
      
      isSendingRef.current = false;
      
      const newSentCount = currentSentCount + 1;
      const newIndex = currentIndex + 1;
      
      setSentCount(newSentCount);
      sentCountRef.current = newSentCount;
      setSendIndex(newIndex);
      sendIndexRef.current = newIndex;

      const statusAfterSend = campaignStatusRef.current as CampaignStatus;
      if (statusAfterSend === "paused" || statusAfterSend === "idle") {
        return;
      }

      if (newIndex < currentContacts.length) {
        setCountdown(delaySecondsRef.current);
        setCampaignStatus("countdown");
      } else {
        clearTimers();
        setSendIndex(currentContacts.length - 1);
        sendIndexRef.current = currentContacts.length - 1;
        setCampaignStatus("completed");
        queryClient.invalidateQueries({ queryKey: ["/api/sales/stats"] });
        queryClient.invalidateQueries({ queryKey: ["/api/emails"] });
        toast({
          title: "Campaign Complete",
          description: `Successfully sent ${newSentCount} emails`,
        });
      }
    } catch (error) {
      isSendingRef.current = false;
      toast({
        title: "Error",
        description: `Failed to send email to ${contact.email}`,
        variant: "destructive",
      });
      clearTimers();
      setCampaignStatus("paused");
    }
  }, [templates, selectedTemplateId, selectedDatasetId, replaceVariables, clearTimers, toast]);

  useEffect(() => {
    if (campaignStatus === "countdown" && countdown > 0) {
      countdownIntervalRef.current = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearTimers();
            setCampaignStatus("sending");
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, [campaignStatus, countdown, clearTimers]);

  useEffect(() => {
    if (campaignStatus === "sending") {
      sendNextEmail();
    }
  }, [campaignStatus, sendNextEmail]);

  const startCampaign = () => {
    if (!contacts || contacts.length === 0) return;
    
    clearTimers();
    setSentCount(0);
    sentCountRef.current = 0;
    setSendIndex(0);
    sendIndexRef.current = 0;
    setCountdown(delaySeconds);
    setCampaignStatus("countdown");
  };

  const pauseCampaign = () => {
    clearTimers();
    setCampaignStatus("paused");
  };

  const resumeCampaign = () => {
    if (sendIndexRef.current < (contacts?.length || 0)) {
      setCountdown(delaySecondsRef.current);
      setCampaignStatus("countdown");
    }
  };

  const stopCampaign = () => {
    clearTimers();
    setCampaignStatus("idle");
    setSendIndex(0);
    sendIndexRef.current = 0;
    setSentCount(0);
    sentCountRef.current = 0;
    setCountdown(0);
    setPreviewIndex(0);
  };

  const navigatePreview = (direction: "prev" | "next") => {
    if (!contacts || contacts.length === 0 || campaignStatus !== "idle") return;
    
    if (direction === "prev" && previewIndex > 0) {
      setPreviewIndex((prev) => prev - 1);
    } else if (direction === "next" && previewIndex < contacts.length - 1) {
      setPreviewIndex((prev) => prev + 1);
    }
  };

  useEffect(() => {
    return () => clearTimers();
  }, [clearTimers]);

  useEffect(() => {
    clearTimers();
    setPreviewIndex(0);
    setSendIndex(0);
    sendIndexRef.current = 0;
    setSentCount(0);
    sentCountRef.current = 0;
    setCampaignStatus("idle");
  }, [selectedDatasetId, clearTimers]);

  if (datasetsLoading || templatesLoading || authLoading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid gap-6 lg:grid-cols-2">
          <Skeleton className="h-[400px]" />
          <Skeleton className="h-[400px]" />
        </div>
      </div>
    );
  }

  const totalContacts = contacts?.length || 0;
  const progress = totalContacts > 0 ? (sentCount / totalContacts) * 100 : 0;
  const isRunning = campaignStatus === "countdown" || campaignStatus === "sending";

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Send Email Campaign</h1>
        <p className="text-muted-foreground">
          Select a dataset and template to send bulk emails
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Campaign Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="dataset">Select Dataset</Label>
              <Select
                value={selectedDatasetId}
                onValueChange={setSelectedDatasetId}
                disabled={isRunning}
              >
                <SelectTrigger id="dataset" data-testid="select-dataset">
                  <SelectValue placeholder="Choose a dataset" />
                </SelectTrigger>
                <SelectContent>
                  {datasets && datasets.length > 0 ? (
                    datasets
                      .filter((d) => d.status === "active")
                      .map((dataset) => (
                        <SelectItem key={dataset.id} value={dataset.id}>
                          {dataset.name} ({dataset.recordsCount} contacts)
                        </SelectItem>
                      ))
                  ) : (
                    <SelectItem value="none" disabled>
                      No datasets available
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="template">Select Template</Label>
              <Select
                value={selectedTemplateId}
                onValueChange={setSelectedTemplateId}
                disabled={isRunning}
              >
                <SelectTrigger id="template" data-testid="select-template">
                  <SelectValue placeholder="Choose a template" />
                </SelectTrigger>
                <SelectContent>
                  {templates && templates.length > 0 ? (
                    templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.name}
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="none" disabled>
                      No templates available
                    </SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="delay">Delay Between Emails (seconds)</Label>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <Input
                  id="delay"
                  type="number"
                  min={1}
                  max={3600}
                  value={delaySeconds}
                  onChange={(e) => setDelaySeconds(Math.max(1, parseInt(e.target.value) || 1))}
                  disabled={isRunning}
                  className="w-24"
                  data-testid="input-delay"
                />
                <span className="text-sm text-muted-foreground">seconds</span>
              </div>
            </div>

            <div className="rounded-md border bg-muted/50 p-4">
              <h4 className="mb-2 text-sm font-medium">Campaign Summary</h4>
              <div className="space-y-1 text-sm text-muted-foreground">
                <p>
                  <span className="font-medium">Recipients:</span>{" "}
                  {contactsLoading ? "Loading..." : totalContacts}
                </p>
                <p>
                  <span className="font-medium">Template:</span>{" "}
                  {selectedTemplateId
                    ? templates?.find((t) => t.id === selectedTemplateId)?.name ||
                      "None"
                    : "None"}
                </p>
                <p>
                  <span className="font-medium">Delay:</span> {delaySeconds} second{delaySeconds !== 1 ? "s" : ""} between emails
                </p>
                {totalContacts > 0 && (
                  <p>
                    <span className="font-medium">Est. Duration:</span>{" "}
                    {Math.ceil((totalContacts - 1) * delaySeconds / 60)} minute{Math.ceil((totalContacts - 1) * delaySeconds / 60) !== 1 ? "s" : ""}
                  </p>
                )}
              </div>
            </div>

            {campaignStatus !== "idle" && (
              <div className="space-y-3 rounded-md border p-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        campaignStatus === "completed"
                          ? "default"
                          : campaignStatus === "paused"
                          ? "secondary"
                          : "outline"
                      }
                    >
                      {campaignStatus === "countdown" && "Waiting"}
                      {campaignStatus === "sending" && "Sending"}
                      {campaignStatus === "paused" && "Paused"}
                      {campaignStatus === "completed" && "Completed"}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {sentCount} / {totalContacts} sent
                    </span>
                  </div>
                  {campaignStatus === "countdown" && (
                    <div className="flex items-center gap-1 text-lg font-mono font-bold">
                      <Clock className="h-4 w-4" />
                      {countdown}s
                    </div>
                  )}
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}

            <div className="flex gap-2 flex-wrap">
              {campaignStatus === "idle" && (
                <Button
                  className="flex-1"
                  onClick={startCampaign}
                  disabled={
                    !selectedDatasetId ||
                    !selectedTemplateId ||
                    totalContacts === 0 ||
                    contactsLoading
                  }
                  data-testid="button-start-campaign"
                >
                  <Play className="h-4 w-4" />
                  Start Campaign
                </Button>
              )}

              {isRunning && (
                <Button
                  variant="secondary"
                  onClick={pauseCampaign}
                  data-testid="button-pause-campaign"
                >
                  <Pause className="h-4 w-4" />
                  Pause
                </Button>
              )}

              {campaignStatus === "paused" && (
                <Button
                  onClick={resumeCampaign}
                  data-testid="button-resume-campaign"
                >
                  <Play className="h-4 w-4" />
                  Resume
                </Button>
              )}

              {(isRunning || campaignStatus === "paused") && (
                <Button
                  variant="destructive"
                  onClick={stopCampaign}
                  data-testid="button-stop-campaign"
                >
                  <Square className="h-4 w-4" />
                  Stop
                </Button>
              )}

              {campaignStatus === "completed" && (
                <Button
                  variant="outline"
                  onClick={stopCampaign}
                  data-testid="button-reset-campaign"
                >
                  Reset
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <CardTitle>
              {campaignStatus === "idle" ? "Email Preview" : "Next Email Preview"}
            </CardTitle>
            {contacts && contacts.length > 0 && (
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigatePreview("prev")}
                  disabled={campaignStatus !== "idle" || previewIndex === 0}
                  data-testid="button-prev-preview"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm text-muted-foreground min-w-[60px] text-center">
                  {displayIndex + 1} / {contacts.length}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => navigatePreview("next")}
                  disabled={campaignStatus !== "idle" || previewIndex >= contacts.length - 1}
                  data-testid="button-next-preview"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            {selectedTemplateId && contacts && contacts.length > 0 ? (
              <>
                <div className="rounded-md border bg-muted/30 p-3">
                  <Label className="text-xs text-muted-foreground">To</Label>
                  <div className="text-sm font-medium">
                    {preview.recipientName ? `${preview.recipientName} <${preview.recipientEmail}>` : preview.recipientEmail}
                  </div>
                </div>
                <div>
                  <Label>Subject</Label>
                  <div className="mt-1 rounded-md border bg-muted/30 p-3 text-sm">
                    {preview.subject || "Subject will appear here"}
                  </div>
                </div>
                <div>
                  <Label>Body</Label>
                  <div 
                    className="mt-1 max-h-[250px] overflow-y-auto rounded-md border bg-card p-3 text-sm prose prose-sm dark:prose-invert max-w-none text-foreground [&_*]:text-foreground [&_a]:text-blue-600 dark:[&_a]:text-blue-400"
                    dangerouslySetInnerHTML={{ __html: preview.body || "<p>Email body will appear here</p>" }}
                  />
                </div>
                {campaignStatus === "countdown" && (
                  <div className="flex items-center justify-center gap-2 rounded-md border border-primary/50 bg-primary/10 p-4">
                    <Clock className="h-5 w-5 text-primary" />
                    <span className="text-lg font-bold text-primary">
                      Sending in {countdown} second{countdown !== 1 ? "s" : ""}...
                    </span>
                  </div>
                )}
                {campaignStatus === "sending" && (
                  <div className="flex items-center justify-center gap-2 rounded-md border border-primary/50 bg-primary/10 p-4">
                    <Send className="h-5 w-5 text-primary animate-pulse" />
                    <span className="text-lg font-bold text-primary">
                      Sending email...
                    </span>
                  </div>
                )}
              </>
            ) : selectedTemplateId ? (
              <div className="flex h-[300px] items-center justify-center text-center text-muted-foreground">
                <p>{contactsLoading ? "Loading contacts..." : "No contacts in selected dataset"}</p>
              </div>
            ) : (
              <div className="flex h-[300px] items-center justify-center text-center text-muted-foreground">
                <p>Select a dataset and template to see preview</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
